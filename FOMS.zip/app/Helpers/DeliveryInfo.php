<?php

namespace App\Helpers;

class DeliveryInfo extends \Illuminate\Database\Eloquent\Casts\Json
{
    public $name;

}
