<?php

namespace App\Helpers;

use App\Models\Notification;

class NotificationHelper
{
    public static function deleteOrderNoti($uid,$refId){
        $old_notf=Notification::orders()->where('user_id',$uid)
            ->where('reference_id',$refId)->delete();
    }
    public static function deleteAllOrderNoti($uid){
        $old_notf=Notification::orders()->where('user_id',$uid)->delete();
    }
}
