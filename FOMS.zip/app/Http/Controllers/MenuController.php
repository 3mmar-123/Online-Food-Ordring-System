<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Menu;
use App\Models\Restaurant;
use Carbon\Carbon;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    /**
     * Display all menu items for a restaurant.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $menus = auth()->user()->restaurant->menus;
        return view('owner.menus.index', compact('menus'));
    }

    public function viewMenu($restaurantId)
    {
        $restaurant = Restaurant::find($restaurantId);
        $menus = $restaurant->menus;
        return view('restaurant.menus', compact('menus', 'restaurant'));
    }

    public function menuView()
    {
        $menuID = \request()->query->get('id');
        $menu = Menu::find($menuID);
        if (!auth()->user()->cart)
            auth()->user()->cart= Cart::create([
                'user_id' => auth()->id(),
                'client_ip' => \request()->getClientIp(),
                'status' => 0
            ]);

        $qty = (auth()->user()->cart->items()->whereMenuId($menuID)->first()?->quantity) ?? 1;

        $view = view('restaurant.view_prod', compact('menu', 'qty'))->render();
        return response()->json(['modal' => $view]);
    }

    /**
     * Show the form to create a new menu item.
     *
     */
    public function create()
    {
        $menu = new \stdClass();

        $modal = view('forms.menu-frm', compact('menu'))->render();
        return response()->json(['modal' => $modal]);
    }

    /**
     * Store a new menu item.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'description' => 'required|string',
            'price' => 'required|numeric',
        ]);
        $restaurant = auth()->user()->restaurant;

        $imgPath = null;
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $currentDate = Carbon::now()->format('Y_m_d_His');
            $extension = $image->getClientOriginalExtension();
            $imageName = $restaurant->restaurant_name . '_menu_' . $request->name . '_' . $currentDate . '.' . $extension;
            $imgPath = $image->storeAs('media/images/dishes', $imageName, ['disk' => 'media']);
        }
        if($request->mid){
            $menu=Menu::find($request->mid);
            $menu->update($request->only('name', 'description', 'price'));
        }
        else
            $menu = $restaurant->menus()->create($request->only('name', 'description', 'price'));

        if ($imgPath) {
            $menu->image_url = $imgPath;
            $menu->save();
        }
        return back()->with('success', 'Menu item '.($request->mid? 'updated':'added').' successfully.');
    }

    /**
     * Show the form to edit an existing menu item.
     *
     * @param \App\Models\Menu $menu
     */
    public function edit(Menu $menu)
    {
        $modal = view('forms.menu-frm', compact('menu'))->render();
        return response()->json(['modal' => $modal]);
    }


    /**
     * Delete a menu item.
     *
     * @param \App\Models\Menu $menu
     */
    public function destroy($menu)
    {
        Menu::find($menu)->delete();
        return back()->with('success', 'Menu item deleted successfully.');
    }
}
