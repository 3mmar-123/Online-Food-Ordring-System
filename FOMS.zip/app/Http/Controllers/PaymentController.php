<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /**
     * Handle payment for an order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function processPayment(Request $request, Order $order)
    {
        // Simulate payment processing
        $payment = Payment::create([
            'order_id' => $order->id,
            'amount' => $order->total_amount,
            'method' => $request->get('method'),
            'status' => 'success'
        ]);

        $order->update(['status' => 'completed']);
        return redirect()->route('customer.orders')->with('success', 'Payment successful.');
    }
}
