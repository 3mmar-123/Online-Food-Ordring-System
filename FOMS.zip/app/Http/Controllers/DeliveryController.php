<?php

namespace App\Http\Controllers;

use App\Models\Delivery;
use App\Models\Order;
use App\Models\User;
use Illuminate\Http\Request;

class DeliveryController extends Controller
{
    /**
     * Show the delivery agent dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $deliveries = User::agents();
        return view('delivery.dashboard', compact('deliveries'));
    }
    /**
     * Show the delivery agent dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
        $deliveries = Delivery::where('agent_id', auth()->id())->get();
        return view('delivery.dashboard', compact('deliveries'));
    }

    /**
     * List all orders assigned to the delivery agent.
     *
     * @return \Illuminate\View\View
     */
    public function listOrders()
    {
        $deliveries = Delivery::where('agent_id', auth()->id())->get();
        return view('delivery.orders', compact('deliveries'));
    }

    /**
     * Update the delivery status of an order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, Order $order)
    {
        $delivery = Delivery::where('order_id', $order->id)
            ->where('agent_id', auth()->id())
            ->first();

        $delivery->update(['delivery_status' => $request->status]);

        return redirect()->route('agent.orders')->with('success', 'Delivery status updated.');
    }
}
