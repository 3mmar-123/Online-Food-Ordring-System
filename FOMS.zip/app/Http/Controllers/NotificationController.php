<?php

namespace App\Http\Controllers;

use App\Helpers\NotificationHelper;
use App\Models\Notification;
use App\Models\Order;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    /**
     * Show notifications for the authenticated user.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $notifications = auth()->user()->notifications()->latest()->get();
        return view('customer.notifications', compact('notifications'));
    }

    /**
     * Show order details.
     *
     * @param \App\Models\Notification $notification
     */
    public function show(Notification $notification)
    {
        $url=$notification->goto_url;
        $notification->delete();
        return redirect($url);
    }
}
