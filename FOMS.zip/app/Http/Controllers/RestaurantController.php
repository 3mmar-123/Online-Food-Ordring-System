<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Restaurant;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RestaurantController extends Controller
{
    /**
     * Show the restaurant owner dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
        $restaurant = auth()->user()->restaurant;
        $customers = Order::where('restaurant_id', auth()->user()->restaurant->restaurant_id)->count();
        return view('owner.dashboard', compact('restaurant', 'customers'));
    }

    /**
     * Show all restaurants.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $restaurants = Restaurant::all();
        return view('restaurant.index', compact('restaurants'));
    }

    public function nearby()
    {
        abort(404);
        $restaurants = Restaurant::all();

        return view('restaurant.nearby', compact('restaurants'));
    }

    public function nearbyJson()
    {
        $latitude = \request()->query('lat');
        $longitude = \request()->query('lng');
        $radius = 5; // Radius in kilometers

        // Haversine formula to calculate distances
        $restaurants = DB::table('restaurants')
            ->leftJoin('users', 'owner_id', 'users.id')
            ->select(
                'restaurants.id',
                'restaurants.name',
                'restaurants.address',
                'latitude',
                'longitude',
                DB::raw("
                (6371 * acos(
                    cos(radians($latitude)) *
                    cos(radians(latitude)) *
                    cos(radians(longitude) - radians($longitude)) +
                    sin(radians($latitude)) *
                    sin(radians(latitude))
                )) AS distance
            ")
            )
            ->orderBy('distance', 'asc')
            ->having('distance', '<', $radius)
            ->get();

        if ($restaurants->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'No nearby restaurants found.']);
        }

        return response()->json(['success' => true, 'restaurants' => $restaurants]);
    }

    public function search(Request $request)
    {
        $query = $request->input('search');

        if ($query) {
            // Step 1: Search restaurants by name or address
            $restaurants = Restaurant::where('name', 'LIKE', "%{$query}%")
                ->orWhere('address', 'LIKE', "%{$query}%")
                ->get();

            if ($restaurants->isNotEmpty()) {
                // Include menus that match the search for these restaurants
                $results = $restaurants->map(function ($restaurant) use ($query) {
                    $restaurant->menus = $restaurant->menus()->where('name', 'LIKE', "%{$query}%")->get();
                    return $restaurant;
                });
            } else {
                // Step 2: Fallback to searching menus
                $menuMatches = Menu::where('name', 'LIKE', "%{$query}%")->get();

                if ($menuMatches->isNotEmpty()) {
                    // Get unique restaurants for the matched menus
                    $restaurantIds = $menuMatches->pluck('restaurant_id')->unique();

                    $results = Restaurant::whereIn('id', $restaurantIds)->get()->map(function ($restaurant) use ($query) {
                        // Attach matched menus to the restaurant
                        $restaurant->menus = $restaurant->menus()->where('name', 'LIKE', "%{$query}%")->get();
                        return $restaurant;
                    });
                }
            }
            return view('restaurant.search', compact('results', 'query'));
        }
        // If no search query, show all restaurants
        $restaurants = Restaurant::all();
        return view('restaurant.index', compact('restaurants'));

    }

    public function updateProfile(Request $request)
    {
//        $request->validate([
//            'restaurant_name' => 'required',
//            'address' => 'required',
//            'description' => 'nullable',
//            'latitude' => 'required|numeric',
//            'longitude' => 'required|numeric',
//        ]);
        $transBegin = false;

        try {
            DB::beginTransaction();
            $transBegin = true;
            $user = auth()->user();
            $imgPath = null;
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $currentDate = Carbon::now()->format('Y_m_d_His');
                $extension = $image->getClientOriginalExtension();
                $imageName = $request->restaurant_name . '_' . $currentDate . '.' . $extension;
                // Use the storeAs method to save the image and get the path
                $imgPath = $image->storeAs('media/images', $imageName, ['disk' => 'media']);
            }

            if (!$user->restaurant) {
                $restaurant = Restaurant::create([
                    'owner_id' => $user->id,
                    'name' => $request->restaurant_name,
                    'address' => $request->address,
                    'logo_url' => $imgPath,
                    'phone' => $request->phone ?? $user->phone,
                    'description' => $request->description
                ]);
            } else {
                $restaurant = $user->restaurant;
                $imgPath = $imgPath ?? $restaurant->logo_url;
                $restaurant->update([
                    'name' => $request->restaurant_name ?? $restaurant->name,
                    'address' => $request->address ?? $restaurant->address,
                    'logo_url' => $imgPath,
                    'phone' => $request->phone ?? $user->phone,
                    'description' => $request->description ?? $restaurant->description
                ]);
                $restaurant->save();
            }
            $user->update([
                'latitude' => $request->latitude ?? $user->latitude,
                'longitude' => $request->longitude ?? $user->longitude,
            ]);
            $user->save();
            DB::commit();
            $transBegin = false;
            return view('index', compact('user'));
        } catch (\Throwable $e) {
            if ($transBegin)
                DB::rollBack();
            dd($e);
        }

    }

    /**
     * Show restaurant performance reports.
     *
     * @return \Illuminate\View\View
     */
    public function generateReport()
    {
        $restaurant = auth()->user()->restaurants->first();
        $orders = Order::where('restaurant_id', $restaurant->restaurant_id)->get();
        $totalSales = $orders->sum('total_amount');
        return view('restaurant.reports', compact('restaurant', 'totalSales'));
    }
}
