<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Menu;
use Illuminate\Http\Request;

class CartController extends Controller
{

    /**
     * @var Cart|null $cart
     */
    private $cart;

    public function __construct()
    {
        if (!auth()->user()->cart)
            auth()->user()->cart=Cart::create([
                'user_id' => auth()->id(),
                'client_ip' => \request()->getClientIp(),
                'status' => 0
            ]);

        $this->cart=auth()->user()->cart;
    }

    public function index()
    {

        return view('customer.cart', ['cart' => $this->cart,'total'=>0]);
    }

    public function destroyItem($id)
    {
        CartItem::find($id)->delete();
        if(auth()->user()->cart->items->isEmpty()) {
            auth()->user()->cart->restaurant_id=null;
            auth()->user()->cart->status=0;
            auth()->user()->cart->save();
        }
        return redirect()->route('cart.index');
    }
    public function emptyCart()
    {
        if(auth()->user()->cart) {
            auth()->user()->cart->items()->delete();
            auth()->user()->cart->restaurant_id=null;
            auth()->user()->cart->status=0;
            auth()->user()->cart->save();
            return back()->with('success','Cart cleared');
        }
        return back()->with('error','Cart is empty');
    }

    public function addItem(Request $request)
    {
        if ($this->cart->status == 0) {
            $this->cart->status = 1;
            $this->cart->restaurant_id = Menu::find($request->mid)->restaurant_id;
            $this->cart->save();
        }
        $menu=Menu::find($request->mid);
        if($this->cart->restaurant_id!=$menu->restaurant_id)
            return response()->json(['status'=>'error','message'=>'Items from different restaurants not allowed<br/> Please placement or clear your cart first.']);

        $cartItem = auth()->user()->cart->items()->whereMenuId($request->mid)
            ->first();
        if ($cartItem) {
            $cartItem->update(['quantity' => ($request->qty)]);
        } else {
            $cartItem = auth()->user()->cart->items()->create([
                'quantity' => $request->qty,
                'menu_id' => $request->mid,
            ]);
        }
        return response()->json(['status' => 'success', 'message' => 'Menu added']);
    }

    public function updateQuantity(Request $request)
    {
        CartItem::find($request->id)->update(['quantity' => $request->qty]);

        return response(1);
    }

    public function checkout()
    {

        $cart = auth()->user()->cart;
        if ($cart->status == 0) {
            return response()->json(['status' => 'warning', 'message' => 'Your Cart is Empty']);
        }
        $total = 0;
        foreach ($cart->items as $item) {
            $total += $item->quantity * $item->menu->price;
        }
        $view = view('customer.checkout', compact('total'))->render();
        return response()->json(['modal' => $view]);
    }
}
