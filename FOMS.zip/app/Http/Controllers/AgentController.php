<?php

namespace App\Http\Controllers;

use App\Helpers\NotificationHelper;
use App\Models\Agent;
use App\Models\Delivery;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Restaurant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Mockery\Exception;
use function Symfony\Component\Translation\t;

class AgentController extends Controller
{
    private $restaurantId = 0;

    public function __construct()
    {
        abort(404);
        $role = auth()->user()->role;
        if ($role == 'owner')
            $this->restaurantId = auth()->user()->restaurant->id;
        elseif ($role == 'agent')
            $this->restaurantId = auth()->user()->agent->restaurant_id;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $agents = Agent::forRestaurant(auth()->user()->restaurant->id)->get();
        return view('owner.agents', compact('agents'));
    }

    /**
     * Display a listing of the tasks.
     */
    public function tasks()
    {
        //
        $deliveries = Delivery::forAgent(auth()->user()->agent->id)->get();
        return view('agent.tasks', compact('deliveries'));
    }

    /**
     * Update a Delivery Status.
     */
    public function updateDeliveryStatus(Request $request)
    {
        //
        $delivery = Delivery::findOrFail($request->id);
        $status = 'error';
        $message = 'Status updating failed';
        if($delivery->delivery_status=='delivered'||$delivery->order->status!='delivering')
            return response()->json([]);
        $newStatus = $delivery->delivery_status == 'assigned' ? 'in_transit' : 'delivered';
        if ($delivery->update(['delivery_status' => $newStatus])) {
            $status = 'success';
            $message = 'Status updated successfully';
        }
        if($delivery->delivery_status=='delivered'){
            $notification = Notification::create([
                'message' => "Please confirm your order delivering.",
                'user_id' => $delivery->order->customer_id,
                'reference_id' => $delivery->order_id,
                'related' => Order::class,
                'goto_url' => route('customer.orders')
            ]);
        }
        return response()->json(['status' => $status, 'message' => $message]);
    }
    /**
     * Update a Delivery Status.
     */
    public function confirmDelivery($id)
    {
        //
        $delivery = Delivery::findOrFail($id);
        $status = 'error';
        $message = 'Confirming failed';
        abort_if($delivery->order->customer_id!=auth()->id()||$delivery->delivery_status!='delivered'||$delivery->order->status!='delivering',503);
        $transBegin=false;
        try {
            DB::beginTransaction();
            $transBegin=true;
            $delivery->order()->update(['status' => 'completed']);
            $payment_method=json_decode($delivery->order->delivery_info)->payment_method;
            if($payment_method=='cod'){
                $payment=Payment::create([
                    'order_id' => $delivery->order_id,
                    'amount' => $delivery->order->total_amount,
                    'payment_date' => now(),
                    'status' => 'success',
                    'method' => 'cash'

                ]);
            }
            NotificationHelper::deleteOrderNoti($delivery->order->customer_id,$delivery->order_id);
            NotificationHelper::deleteOrderNoti($delivery->agent->user_id,$delivery->order_id);
            NotificationHelper::deleteOrderNoti($delivery->agent->restaurant->owner_id,$delivery->order_id);

            $notification = Notification::create([
                'message' => "Delivering Confirmed.",
                'user_id' => $delivery->agent->user_id,
                'reference_id' => $delivery->order_id,
                'related' => Order::class,
                'goto_url' => route('agent.orders')
            ]);
            $notification = Notification::create([
                'message' => "Delivering Confirmed.",
                'user_id' => $delivery->agent->restaurant->owner_id,
                'reference_id' => $delivery->order_id,
                'related' => Order::class,
                'goto_url' => route('owner.orders')
            ]);
            DB::commit();
            $transBegin=false;
            return back()->with('success','Delivery Confirmed.');

        }catch (\Throwable $e){
            if($transBegin)
                DB::rollBack();
            return response()->json(['status'=>'error','message'=>$e->getMessage()]);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $agent = new \stdClass();
        $modal = view('forms.agent-frm', compact('agent'))->render();
        return response()->json(['modal' => $modal]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:50',
            'email' => 'required|email',
            'phone' => 'required',
            'transportation' => 'nullable',
        ]);
        $transBegin = false;
        try {
            abort_if(auth()->user()->role != 'owner', 503);
            DB::beginTransaction();
            $transBegin = true;
            if ($request->aid) {
                $agent = Agent::find($request->aid);
                $user = User::find($agent->user_id);
                if ($user->email != $request->email)
                    $request->validate([
                        'email' => 'required|email|unique:users,email',
                    ]);
                $user->update([
                    'name' => $request->name,
                    'email' => $request->email,
                    'phone' => $request->phone,
                    'role' => 'agent',
                ]);
                if ($request->npassword) {
                    $user->password = Hash::make($request->npassword);
                    $user->save();
                }
                $agent->update($request->only(['transportation']));

            } else {
                $request->validate([
                    'email' => 'required|email|unique:users,email',
                    'password' => 'required',
                ]);
                $user = User::create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'phone' => $request->phone,
                    'role' => 'agent',
                    'password' => Hash::make($request->password),
                ]);
                Agent::create([
                    'restaurant_id' => auth()->user()->restaurant->id,
                    'user_id' => $user->id,
                    'transportation' => $request->transportation,
                    'status' => 0,
                ]);
            }
            DB::commit();
            $transBegin = false;
            return back()->with('success', 'Agent Info Stored Successfully');
        } catch (\Exception $e) {
            if ($transBegin) {
                DB::rollBack();
            }
            return back()->with('error', $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Agent $agent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Agent $agent)
    {
        //
        $modal = view('forms.agent-frm', compact('agent'))->render();
        return response()->json(['modal' => $modal]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function setOrder(Request $request)
    {
        //
        $request->validate([
            'aid' => 'required|exists:agents,id',
            'oid' => 'required|exists:orders,id',
        ]);
        $agent = Agent::findOrFail($request->aid);
        $order = Order::findOrFail($request->oid);
        if ($agent->restaurant_id != $order->restaurant_id || $agent->restaurant_id != $this->restaurantId)
            abort(503);

        $transBegin = false;
        try {
            if ($order->delivery)
                throw new \Exception('This Order has been assigned previously to ' . $order->delivery->agent?->user->name);
            DB::beginTransaction();
            $transBegin = true;
            $delivery = Delivery::create([
                'order_id' => $order->id,
                'agent_id' => $agent->id,
                'delivery_address' => json_decode($order->delivery_info)->address,
                'delivery_status' => 'assigned'
            ]);
            NotificationHelper::deleteOrderNoti($agent->user_id, $order->id);
            $notification = Notification::create([
                'message' => "You have a new order to delivery.",
                'user_id' => $agent->user_id,
                'reference_id' => $order->id,
                'related' => Order::class,
                'goto_url' => route('agent.orders')
            ]);
            $agent->status = 1;
            $agent->save();
            $order->status = 'delivering';
            $order->save();
            DB::commit();
            $transBegin = false;
            return back()->with('success', 'The agent will notified with new order.');
        } catch (\Throwable $e) {
            if ($transBegin)
                DB::rollBack();
            return back()->with('error', $e->getMessage());
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function operations()
    {
        //
        $id = \request()->query->get('id');
        $op = \request()->query->get('op');
        $type = \request()->query->get('a');
        $agents = Restaurant::findOrFail($this->restaurantId)->agents()->availabe()->leftJoin('users', 'users.id', 'user_id')->pluck('users.name', 'agents.id');
        if ($op == 'ao') {
            $orders = auth()->user()->restaurant->orders()->readyToDelivery()->get();
            $modal = view('forms.agent-to-order-frm', compact('orders', 'agents', 'id'))->render();
            return response()->json(['modal' => $modal]);
        }
    }
}
