<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Agent extends Model
{
    protected $fillable = [
        'user_id',
        'restaurant_id',
        'current_latitude',
        'current_longitude',
        'status',
        'transportation',];

    public function scopeAvailabe(Builder $query): Builder
    {
        return $query->where('status',0);
    }
    public function scopeForRestaurant(Builder $query,$restaurantId): Builder
    {
        return $query->where('restaurant_id',$restaurantId);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }
}
