<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Nette\Utils\Json;

/**
 *
 * @property string $status ['pending', 'preparing', 'delivering', 'completed', 'canceled']
 */
class Order extends Model
{
    protected $fillable = ['customer_id', 'restaurant_id', 'order_date'
        , 'status', 'total_amount', 'delivery_info'
        , 'is_favorite', 'hide_from_customer', 'hide_from_owner'];
    protected $casts = [ 'order_date' => 'datetime'];
    protected $attributes=['delivery_info' => Json::class];

    public function getStatusBadge(){
        $badge="dark";
        switch ($this->status){
            case 'pending':
                $badge="warning";
                break;
            case 'preparing':
                $badge="info";
                break;
            case 'delivering':
                $badge="primary";
                if($this->delivery&&$this->delivery->delivery_status=='delivered')
                    $badge="success";
                break;
            case 'rejected':
            case 'canceled':
                $badge="danger";
                break;
            case 'completed':
                $badge="success";
                break;

        }
        return $badge;
    }

    public function scopeReadyToDelivery(Builder $query): Builder
    {
        return $query->where('status','preparing')->orWhere('status','delivering');
    }
    public function scopeForCustomer(Builder $query): Builder
    {
        return $query->where('hide_from_customer',false);
    }
    public function scopeForOwner(Builder $query): Builder
    {
        return $query->where('hide_from_owner',false);
    }
    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class, 'restaurant_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class, 'order_id');
    }

    public function payment(): HasOne
    {
        return $this->hasOne(Payment::class, 'order_id');
    }

    public function delivery(): HasOne
    {
        return $this->hasOne(Delivery::class, 'order_id');
    }

    public static function fillFromCart(Cart $cart)
    {
        $order = new static();
        $order->customer_id = $cart->user_id;
        $order->restaurant_id = $cart->restaurant_id;
        $order->status = 'pending';
        $order->order_date = now();
        $order->total_amount = 0;

        return $order;

    }
}


