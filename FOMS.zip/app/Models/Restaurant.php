<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Restaurant extends Model
{
    protected $fillable = ['owner_id', 'name', 'address', 'cuisine', 'phone', 'logo_url'];

    public function owner():BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function menus():HasMany
    {
        return $this->hasMany(Menu::class, 'restaurant_id');
    }

    public function orders():HasMany
    {
        return $this->hasMany(Order::class, 'restaurant_id');
    }

    public function agents():HasMany
    {
        return $this->hasMany(Agent::class, 'restaurant_id');
    }

}




