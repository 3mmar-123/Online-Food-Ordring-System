<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = ['user_id', 'message', 'is_read','goto_url','reference_id', 'related'];

    public function scopeOrders(Builder $query): Builder
    {
        return $query->where('related',Order::class);
    }
    public function scopeRead(Builder $query): Builder
    {
        return $query->where('is_read',false);
    }
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}

