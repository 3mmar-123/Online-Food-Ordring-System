<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'role', 'longitude', 'latitude',
        'password', 'phone',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function scopeAgents(Builder $query): Builder
    {
        return $query->where('role','agent');
    }
    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function cart(): HasOne
    {
        return $this->hasOne(Cart::class);
    }
    public function restaurant(): HasOne
    {
        return $this->hasOne(Restaurant::class,'owner_id');
    }
    public function agent(): HasOne
    {
        return $this->hasOne(Agent::class,'user_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class,'customer_id')->where('hide_from_customer',false);
    }
    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class,'user_id')->where('is_read',false);
    }

}
