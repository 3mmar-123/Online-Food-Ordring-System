<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Menu extends Model
{
    protected $fillable = ['restaurant_id', 'name', 'description', 'price', 'image_url', 'availability'];

    public function restaurant():BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    public function orderItems():HasMany
    {
        return $this->hasMany(OrderItem::class, 'menu_id');
    }
}


