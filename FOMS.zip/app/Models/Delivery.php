<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Delivery extends Model
{
    protected $table='delivery';
    /*
     * delivery_status ['assigned','in_transit','delivered']
     */
    protected $fillable = ['order_id', 'agent_id', 'delivery_address', 'delivery_status'];
    public function getStatusBadge($confirm=0){
        $badge="dark";
        switch ($this->delivery_status){
            case 'assigned':
                $badge="warning";
                break;
            case 'in_transit':
                $badge="primary";
                break;
            case 'delivered':
                $badge="success";
                if($confirm&&$this->order->status!='completed')
                    $badge='danger';
                break;

        }

        return $badge;
    }

    public function scopeForAgent(Builder $query,$aid): Builder
    {
        return $query->where('agent_id',$aid);
    }
    public function order():BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function agent():BelongsTo
    {
        return $this->belongsTo(Agent::class, 'agent_id');
    }
}
