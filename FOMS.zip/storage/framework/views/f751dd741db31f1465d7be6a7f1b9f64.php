<style>
    #orders-menu .card-text p:last-child, #selected-order .text-muted {
        font-size: 0.7rem;
        text-wrap: balance wrap;
    }
</style>
<form action="<?php echo e(route('agent.assign-order')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="oid" id="order-input" value="">
    <div class="card-body">
        Assign the order
        <div class="btn dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"
             aria-haspopup="true" aria-expanded="false" id="selected-order">
            <span class="sr-only"></span>
        </div>
        <div class="dropdown-menu scrollable-auto" style="height: available" id="orders-menu">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $order->del_info = json_decode($order->delivery_info); ?>

                <div data-id="<?php echo e($order->id); ?>"
                     data-title="<?php echo e($order->del_info->name.'<br/> <span class="text-muted">'.$order->del_info->address.'</span>'); ?>"
                     class="dropdown-item order-item">
                    <div class="card border border-outline-info">
                        <div class="card-title ">
                            <?php echo e($order->del_info->name); ?>

                        </div>
                        <div class="card-text">
                            <p><strong>Status:</strong>
                                <span class="badge badge-<?php echo e($order->getStatusBadge()); ?>">
                                    <?php echo e(ucfirst($order->status)); ?>

                                </span>
                            </p>
                            <p><strong>Total Amount:</strong> $<?php echo e($order->total_amount); ?></p>
                            <p><strong>Items:</strong>
                                <?php echo e(implode(', ', $order->items->map(fn($item) => $item->menu->name)->toArray())); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        to Agent
        <select class="form-select" name="aid">
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e($key==$id?'selected':''); ?>>
                    <?php echo e($name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</form>
<script>
    $('.order-item').on('click', function (e) {
        e.preventDefault();
        $('#uni_modal form #order-input').val(this.dataset.id)
        $('#uni_modal form #selected-order').html(this.dataset.title)
    })
    $('#uni_modal form #orders-menu .order-item').first().click();

</script>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/forms/agent-to-order-frm.blade.php ENDPATH**/ ?>