<?php $__env->startSection('styles'); ?>
    <style>

        @media (min-width: 1281px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/with-png2.png")); ?>');
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/img.png")); ?>');
            }

        }

        @media (min-width: 1025px) and (max-width: 1280px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/first2.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');
            }

        }

        /* Media Query for Tablets Ipads portrait mode */
        @media (min-width: 768px) and (max-width: 1024px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/first2.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');

            }
        }

        /* Media Query for low resolution like mobiles */
        @media (min-width: 320px) and (max-width: 767px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 53% 15%);
            }
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('hero'); ?>
    <!--  Hero Start -->
    <div class="container-fluid bg-primary p-0 hero-header">
        <div class="img-hero">

            <img src="<?php echo e(asset('img/logo4.jpg')); ?>"/>
        </div>
    </div>
    <!--  Hero End -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Clients Trust Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center  wow fadeInUp" data-wow-delay="0.1s">
                <h1>Empowering Education Everywhere!</h1>
            </div>
            <div class="owl-carousel owl-theme testimonial-carousel position-relative">
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/cs.jpg')); ?>" alt=""/>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/math.jpg')); ?>" alt=""/>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/accounting.jpg')); ?>" alt=""/>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/chemistry.jpg')); ?>" alt=""/>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/physics.jpg')); ?>" alt=""/>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <img class="carousel-image"
                         src="<?php echo e(asset('wp-content/uploads/2021/11/it.jpg')); ?>" alt=""/></div>

            </div>
        </div>
        <!-- Clients Trust End -->

        <!-- Choose us Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5">

                    <div class=" wow fadeInUp" data-wow-delay="0.3s">
                        <h1 class="mb-4 text-center">
                            <span>Why Choose MADD?</span></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-xxl quick-response-div-bg row-flex vc_custom_1685098197489 ">
            <div class="container">
                <div class="row white-text">
                    <div class="d-md-block  d-sm-none  col-6 col-md-6"></div>
                    <div class="col-sm-12 col-lg-6 col-md-6">
                        <div class=" why-choose-content-1">
                            <h1 class="mt-3 quick-response-h txt-sub text-center white-text wow fadeInRight"
                                data-wow-delay="0.3s">
                                <span>Innovative Learning Experience</span></h1>
                            <p class=" quick-response-p txt-sub">MADD revolutionizes the learning process with
                                interactive tools and a comprehensive digital platform, facilitating a dynamic
                                educational journey for every student.
                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-xxl one-stop-shop-div-bg row-flex vc_custom_1685100562072 ">
            <div class="container">
                <div class="row white-text">
                    <div class="col-sm-12 col-lg-6 col-md-6 ">
                        <div class=" why-choose-content-2">
                            <h1 class=" wow fadeInLeft one-stop-shop-h text-center white-text" data-wow-delay="0.3s">
                                <span>Expert Educators at Your Fingertips</span></h1>
                            <p class="one-stop-shop-p">Our platform connects students with top educators in their
                                fields, ensuring high-quality learning and personal growth.</p>


                        </div>
                    </div>
                    <div class="d-sm-none col-lg-6 col-md-6"></div>

                </div>
            </div>
        </div>
        <!-- Choose us End -->
        <!-- Quick Response and One Stop Shop Technology Start -->
        <div class="container-xxl row-flex mt-auto">
            <div class="container">
                <div class="row black-text">
                    <div class="col-sm-12 col-lg-6">
                        <h2 style="margin-top: 3rem;">Instant Access to Educational Resources</h2>
                        <p>At MADD, we provide quick and easy access to a vast repository of educational materials,
                            enabling learners to find everything they need in one place.</p>
                    </div>
                    <div class="col-sm-12 col-lg-6">
                        <h2 style="margin-top: 3rem;">Comprehensive Educational Platform</h2>
                        <p>From interactive courses to expert tutorials, MADD offers an all-encompassing educational
                            experience to cater to the diverse needs of our learning community.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Quick Response and One Stop Shop Technology End -->
        <!-- Partner Start -->
        <!-- Partner End -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <div class="container-fluid bg-primary-linear text-light footer bottom-0  wow fadeIn" data-wow-delay="0.1s">
        <!-- Copy Rights -->
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="text-center text-md-start mb-3 mb-md-0">
                        &copy; 2023 <a class="border-bottom" href="#">MADD</a>, All Rights Reserved |
                        Contact Madd:
                        <a href="http://instagram.com/_u/maddweb_4"
                           data-mdb-ripple-init type="button" style="vertical-align: unset;"
                           class="btn hover-shadow text-white btn-floating mx-1">
                            <i class="fab fa-2x  fa-instagram"></i>
                        </a>

                        <a href="mailto: maddwep3@email.com"
                           data-mdb-ripple-init type="button"
                           class="btn hover-shadow text-white btn-floating mx-1">
                            <i class="fab fa-2x fa-google-plus-g"></i>
                        </a> |
                        MADD On-Line Learning Services
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/index.blade.php ENDPATH**/ ?>