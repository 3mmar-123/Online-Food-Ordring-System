<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <div class="container-fluid">
            <div class="card card-outline-primary">
                <div class="card-header">
                    <h4 class="m-b-0 text-white">All Orders</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive m-t-40">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Total Amount</th>
                                <th>Date Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php $order->del_info = json_decode($order->delivery_info); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <th><?php echo e($order->del_info->name??$order->customer->name); ?></th>
                                    <td><?php echo e($order->del_info->address); ?></td>
                                    <td><?php echo e($order->del_info->phone); ?></td>
                                    <td><?php echo e($order->del_info->email); ?></td>
                                    <td><?php echo e($order->total_amount); ?></td>
                                    <td><?php echo e($order->order_date->diffForHumans()); ?></td>
                                    <td>

                                        <div class="dropdown">
                                            <span class="btn badge badge-<?php echo e($order->getStatusBadge()); ?>"
                                                  id="statusesDropdown" data-bs-toggle="dropdown"
                                                  aria-haspopup="true" aria-expanded="false">
                                            <?php echo e(ucfirst($order->status)); ?>

                                        </span>
                                            <div class="dropdown-menu animated fadeIn"
                                                 aria-labelledby="statusesDropdown">
                                                <div class="dropdown-divider"></div>
                                                <?php if($order->status=='canceled'||$order->status=='rejected'): ?>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value="5" class="dropdown-item change-status">Remove</a>
                                                <?php elseif($order->status=='delivering'): ?>


                                                    <a href="#"
                                                       class="dropdown-item change-status" data-id="<?php echo e($order->id); ?>" data-value="4">Cancel</a>

                                                <?php elseif($order->status=='preparing'): ?>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value=2 class="dropdown-item change-status">Deliver</a>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value="3" class="dropdown-item change-status">Reject</a>
                                                <?php elseif($order->status=='pending'): ?>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value=1 class="dropdown-item change-status">Preparing</a>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value=2 class="dropdown-item change-status">Deliver</a>
                                                    <a href="#" data-id="<?php echo e($order->id); ?>"
                                                       data-value="3" class="dropdown-item change-status">Reject</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary view_order" data-id="<?php echo e($order->id); ?>"
                                                data-url="<?php echo e(route('owner.view-order',$order->id)); ?>">View Order
                                        </button>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                No Orders
                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.view_order').click(function (){
            uni_modal('Order Details',this.dataset.url);
        })
        $('.assign-agent').click(function () {
            uni_modal('', '<?php echo e(route('agent.operations')); ?>'+'?id='+this.dataset.id+'&op=ao&a=1');
        })
        $('.change-status').click(function () {
            start_load()
            $.ajax({
                url:'<?php echo e(route("owner.change-order-status")); ?>',
                method:'POST',
                data:{id:this.dataset.id,sid:this.dataset.value,_token:'<?php echo e(csrf_token()); ?>'},
                success:function(resp){
                    if(resp){
                        notify(resp.status||"success",resp.message||"Process completed")
                        setTimeout(function(){
                            location.reload()
                        },1500)
                    }
                },
                error:function (xhr,status,message){
                    console.log(xhr)
                    end_load()
                    notify('error',"Err "+status+" "+message)
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/owner/orders.blade.php ENDPATH**/ ?>