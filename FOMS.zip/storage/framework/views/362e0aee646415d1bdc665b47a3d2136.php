<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 py-5">
        <div class="row mt-5 ">
            <h2>Welcome, <?php echo e(Auth::user()->name); ?>!</h2>
        </div>

        <div class="container my-5">
            <h3>My Learning</h3>
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3>In-Progress</h3>
                        </div>
                        <div class="card-body row">
                            <?php $__empty_1 = true; $__currentLoopData = $inprogress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-12 col-lg-6 course-container mb-4">
                                    <div class="card hover-shadow ">
                                        <img class="card-img-top" src="<?php echo e(asset($course->course->img_path??'img/logo1.webp')); ?>" alt="Course Image">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($course->course->title); ?></h5>
                                            <p class="card-text">Last : <?php echo e($course->lastLesson->module->order.'.'.$course->lastLesson->order.': '. $course->lastLesson->title); ?></p>
                                        </div>
                                        <div class="card-footer">

                                            <a href="<?php echo e(route('course.show',$course->course->id)); ?>" class="btn btn-primary">Go to course</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted text-center ">
                                    You haven't enrollments yet - <a href="<?php echo e(route('course.index')); ?>" class="me-3 link-success">Browse Courses</a>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 bg-gradient">
                    <h4 class="mb-3">Latest Achievements</h4>
                    <div class="mb-3">
                        <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center">
                                <div class="achievement-icon bg-success rounded-circle text-white mr-3">
                                    <i class="fas fa-trophy"></i>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('course.show',$course->course->id)); ?>" class="mb-0"><?php echo e($course->course->title); ?></a>
                                </div>
                                <small><?php echo e($course->course->level->text); ?></small>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/student/student_dashboard.blade.php ENDPATH**/ ?>