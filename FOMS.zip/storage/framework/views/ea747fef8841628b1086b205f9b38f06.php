<?php $__env->startSection('styles'); ?>
    <style>
        .right-div-bg {
            margin-top: 0 !important;
            border-width: thick;
            background: aquamarine;
            border-color: blueviolet;
            opacity: 0.7;
            border: solid;
            border-bottom-left-radius: 450%;
            border-bottom-right-radius: 40%;
            overflow: hidden;
            border-block-end: none;

        }

        .right-div-bg img {
            width: 100% !important;
            height: 100% !important;
        }

        .left-div-bg {
            margin-top: auto !important;
            border-width: thick;
            background: aquamarine;
            border-color: blueviolet;
            opacity: 0.7;
            border: solid;
            border-top-right-radius: 450%;
            border-bottom-right-radius: 40%;
            overflow: hidden;
            border-block-end: none;
        }

        .left-div-bg img {
            width: 100% !important;
            height: 100% !important;
        }

        .who-we-are-bg {
            background: rgb(40 46 18 / 87%);
        }

        .partial-opacity img {
            width: 100% !important;
            height: 100% !important;
            -webkit-mask-image: linear-gradient(to left, transparent, black);
            mask-image: linear-gradient(to left, transparent, black);
        }

        .hero-img-bg {
            background: url("/img/logo4.jpg") no-repeat;
            height: 100vh;

            background-size: cover;

        }

        .hero-img-bg div {
            top: 13%;
            position: relative;
        }

        .txt-sub {
            font-size: 35px;
            font-weight: bold;
            background-color: #47668d;
            opacity: 0.8;
        }

        .text-xxxl {
            font-size: 102px;
            font-weight: bold;
            background-color: #47668d;
            opacity: 0.8;
            line-height: 112px;
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / var(--tw-text-opacity));
            font-family: Playfair auto, serif !important;
            letter-spacing: 1px;
        }
    </style>
    <style>

        @media (min-width: 1281px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;
            }

        }

        @media (min-width: 1025px) and (max-width: 1280px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;
            }
            .txt-sub {
                font-size: 40px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
            }

            .text-xxxl {
                font-size: 80px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
                line-height: 85px;
                --tw-text-opacity: 1;
                color: rgb(255 255 255 / var(--tw-text-opacity));
                font-family: Playfair auto, serif !important;
                letter-spacing: 1px;
            }
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;
            }

        }

        /* Media Query for Tablets Ipads portrait mode */
        @media (min-width: 768px) and (max-width: 1024px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;
            }
            .txt-sub {
                font-size: 30px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
            }

            .text-xxxl {
                font-size: 60px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
                line-height: 65px;
                --tw-text-opacity: 1;
                color: rgb(255 255 255 / var(--tw-text-opacity));
                font-family: Playfair auto, serif !important;
                letter-spacing: 1px;
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

                ;

            }
        }

        /* Media Query for low resolution like mobiles */
        @media (min-width: 320px) and (max-width: 767px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);

            }
            .txt-sub {
                font-size: 20px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
            }

            .text-xxxl {
                font-size: 45px;
                font-weight: bold;
                background-color: #47668d;
                opacity: 0.8;
                line-height: 40px;
                --tw-text-opacity: 1;
                color: rgb(255 255 255 / var(--tw-text-opacity));
                font-family: Playfair auto, serif !important;
                letter-spacing: 1px;
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 53% 15%);
            }
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('hero'); ?>
    <div class="container-fluid  p-0 hero-header hero-img-bg">
        <div class="container-xxl text-white  px-5 mb-1  ">
            <div class="row m-auto">
                <p class=" tracking-wide text-xxxl font-medium mt-2 ">
                    <span class="d-block">Empowering Education</span><span class="d-md-block">Everyone</span></p>
                <p class="txt-sub  mt-3 mt-md-5">through innovation and technology</p>

            </div>


        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Who We Are Start-->
    <div class="container-xxl who-we-are-bg mb-1">
        <div class="row white-text  m-auto">
            <div class=" ms-3">
                <h1 class="mt-3 mb-1 quick-response-h text-center white-text wow fadeInRight"
                    data-wow-delay="0.3s">
                    <span>Who We Are</span></h1>
                <p class="text-center quick-response-p">
                    MADD is a leading educational platform dedicated to bringing the classroom into the digital age. Our
                    mission is to provide comprehensive, accessible, and flexible learning solutions that empower
                    students and educators alike.</p>


            </div>
        </div>
    </div>
    <!-- Who We Are End-->
    <!-- Choose us Start -->
    <div class="container-xxl quick-response-div-bg row-flex vc_custom_1685098197489 " style="ba">
        <div class="container">
            <div class="row white-text">
                <div class="d-md-block  d-sm-none  col-6 col-md-6"></div>
                <div class="col-sm-12 col-lg-6 col-md-6">
                    <div class=" why-choose-content-1">
                        <h1 class="mt-3 quick-response-h text-center white-text wow fadeInRight" data-wow-delay="0.3s">
                            <span>Interactive Learning</span></h1>
                        <p class=" quick-response-p">At MADD, we believe in making learning interactive and engaging.
                            Our platform offers a range of tools and resources that foster an active learning
                            environment for students.</p>

                    </div>
                </div>
                <div class="col-sm-12 col-lg-6">
                    <div class="why-choose-content-2">
                        <h1 class="wow fadeInLeft one-stop-shop-h text-center white-text" data-wow-delay="0.3s">
                            <span>Expert Educators</span></h1>
                        <p class="one-stop-shop-p">Our team comprises experienced educators who are passionate about
                            teaching and are adept at using technology to enhance the learning experience.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Choose us End -->




    <!-- Our Vision Start -->
    <div class="container-xxl bg-primary">
        <div class="row white-text">
            <div class="col-sm-12 col-lg-7">
                <div class="ms-3">
                    <h1 class="mt-3 mb-1 quick-response-h text-center white-text wow fadeInRight" data-wow-delay="0.3s">
                        <span>Our Vision</span></h1>
                    <p class="quick-response-p">
                        To revolutionize the educational landscape by making high-quality education accessible to
                        students across the globe, leveraging technology to bridge educational gaps.</p>
                </div>
            </div>
            <div class="col-lg-5 p-0 d-md-block right-div-bg d-sm-none">
                <img src="<?php echo e(asset('img/logo5.jpg')); ?>">
            </div>
        </div>
    </div>
    <!-- Our Vision End -->

    <!-- Our Mission Start -->
    <div class="container-xxl bg-primary">
        <div class="row white-text">
            <div class="col-lg-5 d-md-block mt-0 p-0 left-div-bg d-sm-none">
                <img src="<?php echo e(asset('img/logo1.webp')); ?>">
            </div>
            <div class="col-sm-12 col-lg-7">
                <div class="ms-3">
                    <h1 class="mt-3 mb-1 quick-response-h text-center white-text wow fadeInRight" data-wow-delay="0.3s">
                        <span>Our Mission</span></h1>
                    <p class="quick-response-p">
                        MADD aims to empower learners by providing innovative educational tools and resources that
                        support and enhance the learning journey. We strive to make education more engaging, accessible,
                        and effective for everyone.</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/about.blade.php ENDPATH**/ ?>