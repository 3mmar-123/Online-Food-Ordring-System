<div class="header">
    <nav class="navbar top-navbar navbar-expand-md navbar-light">
        <div class="navbar-header">

            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                Food Ordering
            </a>
        </div>

        <div class="navbar-collapse">
            <ul class="navbar-nav ml-auto mt-md-0">

            <!-- Notifications -->
            <li class="nav-item dropdown ">
                <a class="nav-link dropdown-toggle text-muted" href="#" id="notificationsDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-bell"></i>
                    <span class="badge badge-danger"><?php echo e(auth()->user()->notifications->count()); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right animated fadeIn fadeInDown" aria-labelledby="notificationsDropdown">
                    <h6 class="dropdown-header">Notifications</h6>
                    <div class="dropdown-divider"></div>
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e($notification->goto_url ?? '#'); ?>" class="dropdown-item">
                            <i class="fa fa-info-circle text-primary"></i> <?php echo e($notification->message); ?>

                            <br>
                            <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                        </a>
                        <div class="dropdown-divider"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="dropdown-item text-center text-muted">No new notifications</a>
                    <?php endif; ?>
                </div>
            </li>

            <!-- User Profile -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-muted" href="#" id="userDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img src="<?php echo e(asset(auth()->user()->restaurant->logo_url)); ?>" alt="user" class="profile-pic" />
                </a>
                <div class="dropdown-menu dropdown-menu-right animated zoomIn" aria-labelledby="userDropdown">
                    <ul class="dropdown-user">
                        <li><a href="<?php echo e(route('logout')); ?>"><i class="text-danger fa fa-sign-out"></i> Logout</a></li>
                    </ul>
                </div>
            </li>
            </ul>
        </div>

    </nav>
</div>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/layouts/admin-header.blade.php ENDPATH**/ ?>