<?php $__env->startSection('styles'); ?>
    <style>

        @media (min-width: 1281px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/first2.png")); ?>');
            }

        }

        @media (min-width: 1025px) and (max-width: 1280px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/first2.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');
            }

        }

        /* Media Query for Tablets Ipads portrait mode */
        @media (min-width: 768px) and (max-width: 1024px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/first2.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');

            }
        }

        /* Media Query for low resolution like mobiles */
        @media (min-width: 320px) and (max-width: 767px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 53% 15%);
            }
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Choose us Start -->
    <div class="container-xxl mt-5 py-5">
        <div class="container">
            <div class="row g-5">
                <div class="card profile-card shadow-1-strong"
                     style="background-color: #8BC34A; border-radius: 20px;">
                    <div class="card-body d-flex align-items-center p-4">
                        <div class="d-flex align-items-center">
                            <div class="avatar me-3">


                                <span class="rounded-circle d-flex justify-content-center align-items-center"
                                      style="width: 50px; height: 50px; background-color: #455A64; color: white;"><?php echo e(substr(\Illuminate\Support\Facades\Auth::user()->name,0,1)); ?></span>
                            </div>
                            <div>
                                <h5 class="card-title mb-2 text-white"><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h5>
                                <p class="card-text text-white"><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                        class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </p>
                            </div>
                        </div>
                        <div class="ms-auto">
                            <button type="button" class="btn btn-light btn-rounded me-2">+ FOLLOW</button>
                            <button type="button" class="btn btn-light btn-rounded">SEE PROFILE</button>
                        </div>
                        <a href="#" class="text-white ms-4"><i class="fas fa-eye"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-xxl product_index_page  row-flex  ">
        <div class="content">
            <div class="con">
                <div class="case">
                    <a class="img" href="/en/product/mixpad_x.html">
                        <img class="lazy"
                             data-original="/img/products/IMG-20240204-WA0012.jpg"
                             alt=""
                             src="<?php echo e(asset('img/logo1.webp')); ?>">
                    </a>
                    <a class="subtitle" href="/en/product/mixpad_x.html">MixPad X Smart Panel</a>
                    <div class="buyWrapper">
                        <p class="desc">All-in-one Full Screen Smart Home Gateway</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/mixpad_7_ultra.html">
                        <img class="lazy"
                             data-original="/img/products/mixpad_7ultra/product-e0c57d88e5.png"
                             alt=""
                             src="<?php echo e(asset('img/logo1.webp')); ?>">
                    </a>
                    <a class="subtitle" href="/en/product/mixpad_7_ultra.html">MixPad 7 Ultra Smart Panel</a>
                    <div class="buyWrapper"><p class="desc">All-in-one Multi-protocol Smart Gateway</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/mixpad_7.html">
                        <img class="lazy"
                             data-original="/img/products//mixpad_7/product-08ab3fcd26.png"
                             alt=""
                             src="<?php echo e(asset('img/logo1.webp')); ?>">
                    </a>
                    <a class="subtitle" href="/en/product/mixpad_7.html">ORVIBO MixPad 7 Multifunctional Control
                        Panel</a>
                    <div class="buyWrapper"><p class="desc">Multi-protocol Smart Home Gateway</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/mixpad_elf.html">
                        <img class="lazy"
                             style="width: 217px; height: 219px;"
                             data-original="/img/products/sec1_elf-58a058f655.png"
                             alt=""
                             src="<?php echo e(asset('img/logo1.webp')); ?>">
                    </a>
                    <a class="subtitle" href="/en/product/mixpad_elf.html">MixPad Genie</a>
                    <div class="buyWrapper"><p class="desc">Smart Panel&nbsp;&nbsp;Funny Life</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/mixpad_mini.html">
                        <img class="lazy"
                             style="width: 221px; height: 219px;"
                             data-original="/img/products/sec1_5-9593c71bce.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0008.jpg">
                    </a>
                    <a class="subtitle" href="/en/product/mixpad_mini.html">MixPad Mini Super Smart Panel</a>
                    <div class="buyWrapper"><p class="desc">Full screen super smart panel</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/mixpads.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_1-61c51251f1.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0007.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/mixpads.html">MixPad
                        S All-in-one Gateway Panel</a>
                    <div class="buyWrapper"><p class="desc">One panel all smart</p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/miniHost.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_3-255908064c.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0006.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/miniHost.html">ZigBee
                        Mini Hub</a>
                    <div class="buyWrapper"><p class="desc">Connect many of smart devices to create<br>smart scenes</p>
                    </div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0005.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0004.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0003.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240204-WA0002.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240130-WA0056.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240130-WA0055.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240130-WA0054.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
                <div class="case">
                    <a class="img" href="/en/product/allone.html">
                        <img class="lazy"
                             data-original="/img/products/sec1_4-5e4f94c995.png"
                             alt=""
                             src="/img/products/IMG-20240130-WA0053.jpg"
                             style=""> </a>
                    <a class="subtitle"
                       href="/en/product/allone.html">Allone
                        Pro RF &amp; IR Hub</a>
                    <div class="buyWrapper"><p class="desc">Smart linking bridge &amp; hub for kinds of<br>RF or IR
                            devices
                        </p></div>
                </div>
            </div>

        </div>
    </div>
    <!-- Choose us End -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/teacher_dashboard2.blade.php ENDPATH**/ ?>