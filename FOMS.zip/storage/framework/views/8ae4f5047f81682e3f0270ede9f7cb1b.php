<form action="<?php echo e(route('agent.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-outline col-sm-12">
        <label for="example-text-input" class="form-label">Name</label>
        <input class="form-control" type="text" name="name"
               id="example-text-input">
    </div>
    <div class="row mt-2">
        <div class="form-outline col-sm-6">
            <label for="exampleInputEmail1" class="form-label">Email</label>
            <input type="text" class="form-control" name="email"
                   id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="form-outline col-sm-6">
            <label for="example-tel-input-3" class="form-label">Phone</label>
            <input class="form-control" type="text" name="phone"
                   id="example-tel-input-3">
        </div>
    </div>
    <div class="row mt-2">
        <div class="form-outline col-sm-6">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" name="password"
                   id="exampleInputPassword1">
        </div>
        <div class="form-outline col-sm-6">
            <label for="example-trans-input-3" class="form-label">Transportation</label>
            <input class="form-control" type="text" name="transportation"
                   id="example-trans-input-3">
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <p><input type="submit" value="Save" name="submit"
                      class="btn theme-btn"></p>
        </div>
    </div>
</form>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/forms/new-agent.blade.php ENDPATH**/ ?>