<?php $__env->startSection('title'); ?>
    منصة مدد - عرض الكورس
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5 mb-5 ml-3 mr-3">
                    <div class="card-header bg-dark"><strong>تفاصيل الكورس</strong>
                        <a href="<?php echo e(route('admin.course.index')); ?>" class="float-right" style="font-size: 26px;"><i class="fas fa-arrow-circle-left"></i></a>
                    </div>
                    <div class="card-body pl-5">
                        <div class="row mb-4">
                            <img class="img-fluid" src="<?php echo e(asset($course->img_path)); ?>" alt="صورة">
                        </div>
                        <div class="row">
                            <h4> <span class="text-primary">الكورس:</span>  <strong><?php echo e($course->title); ?></strong></h4>
                            <span style="color: grey"> - أضيف بواسطة <span style="color: rgb(60, 43, 158); font-weight: bold"><?php echo e($course->teacher?->name?:'غير معروف'); ?></span> منذ <?php echo e($course->created_at?->diffForHumans()); ?></span>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">الوصف:</span>  <strong><?php echo e($course->description); ?></strong></p>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">نوع الكورس:</span> <strong><?php echo e($course->category?->ar_text?:'غير معروف'); ?></strong></p>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">المستوى:</span> <strong><?php echo e($course->level?->ar_text?:'غير معروف'); ?></strong></p>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">الحالة:</span> <strong><?php echo e($course->progress?->ar_text?:'غير معروف'); ?></strong></p>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">تاريخ البدء:</span> <strong><?php echo e($course->start_date??"غير محدد"); ?></strong></p>
                        </div>
                        <div class="row">
                            <p><span class="text-primary">تاريخ الاكتمال:</span> <strong><?php echo e($course->end_date??"غير محدد"); ?></strong></p>
                        </div>
                        <hr>
                        <div class="row text-primary">
                            <h4>تفاصيل أخرى:</h4>
                        </div>
                        <div class="row mt-1 mb-2">
                            <p style="text-align: justify"><?php echo nl2br(e($course->enrollments_count)); ?> طالب </p>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('admin.course.index')); ?>" class="btn btn-danger">رجوع</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>