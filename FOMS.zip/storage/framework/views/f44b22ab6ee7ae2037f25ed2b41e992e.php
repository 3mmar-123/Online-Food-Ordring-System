<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .question-container { margin-top: 20px; }
        .edit-icon { cursor: pointer; }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <!-- Assignment Details Card -->
    <div class="card">
        <div class="card-header">
            <h2>Assignment Details</h2>
        </div>
        <div class="card-body">
            <h5 class="card-title">Assignment Title: Midterm Exam</h5>
            <p class="card-text">Type: MidExam</p>
            <p class="card-text">Description: A comprehensive exam covering all topics taught in the first half of the course.</p>
            <p>If file exists, download link here</p>
            <p class="card-text">Available Time: 2 hours</p>
            <p class="card-text">Total Marks: 100</p>
            <p class="card-text">Open Date: 2024-04-01</p>
            <p class="card-text">Close Date: 2024-04-10</p>
        </div>
    </div>

    <!-- Questions Section -->
    <div class="question-container">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addQuestionModal">
            Add New Question
        </button>

        <ul class="list-group mt-3">
            <!-- Dynamic listing of questions -->
            <li class="list-group-item">
                What does HTML stand for?
                <ul class="list-group">
                    <li class="list-group-item">A: Hyper Text Markup Language</li>
                    <li class="list-group-item">B: Home Tool Markup Language</li>
                    <li class="list-group-item">C: Hyperlinks and Text Markup Language</li>
                </ul>
                <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal" data-bs-target="#addQuestionModal"></span>
            </li>
            <li class="list-group-item">
                Which language runs in a web browser?
                <ul class="list-group">
                    <li class="list-group-item">A: Java</li>
                    <li class="list-group-item">B: C</li>
                    <li class="list-group-item">C: JavaScript</li>
                    <li class="list-group-item">D: Python</li>
                </ul>
                <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal" data-bs-target="#addQuestionModal"></span>
            </li>
            <li class="list-group-item">
                What does CSS stand for?
                <ul class="list-group">
                    <li class="list-group-item">A: Computer Style Sheets</li>
                    <li class="list-group-item">B: Creative Style Sheets</li>
                    <li class="list-group-item">C: Cascading Style Sheets</li>
                    <li class="list-group-item">D: Colorful Style Sheets</li>
                </ul>
                <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal" data-bs-target="#addQuestionModal"></span>
            </li>
            <li class="list-group-item">
                What is the correct HTML for referring to an external style sheet?
                <ul class="list-group">
                    <li class="list-group-item">A: <code>&lt;stylesheet&gt;mystyle.css&lt;/stylesheet&gt;</code></li>
                    <li class="list-group-item">B: <code>&lt;style src="mystyle.css"&gt;</code></li>
                    <li class="list-group-item">C: <code>&lt;link rel="stylesheet" type="text/css" href="mystyle.css"&gt;</code></li>
                </ul>
                <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal" data-bs-target="#addQuestionModal"></span>
            </li>
            <li class="list-group-item">
                Which is the correct syntax for referring to an external script called "xxx.js"?
                <ul class="list-group">
                    <li class="list-group-item">A: <code>&lt;script href="xxx.js"&gt;</code></li>
                    <li class="list-group-item">B: <code>&lt;script name="xxx.js"&gt;</code></li>
                    <li class="list-group-item">C: <code>&lt;script src="xxx.js"&gt;</code></li>
                </ul>
                <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal" data-bs-target="#addQuestionModal"></span>
            </li>
        </ul>
    </div>

    <!-- Modal for Adding/Editing Questions -->
    <div class="modal fade" id="addQuestionModal" tabindex="-1" aria-labelledby="addQuestionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addQuestionModalLabel">Add/Edit Question</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="questionForm">
                        <div class="mb-3">
                            <label for="questionText" class="form-label">Question</label>
                            <input type="text" class="form-control" id="questionText" required>
                        </div>
                        <div class="mb-3">
                            <label for="marks" class="form-label">Marks</label>
                            <input type="number" class="form-control" id="marks" required>
                        </div>
                        <div class="mb-3">
                            <label for="questionType" class="form-label">Question Type</label>
                            <select class="form-select" id="questionType" required>
                                <option value="">Select Question Type</option>
                                <option value="multi-choice">Multi-Choice</option>
                                <option value="true-false">True/False</option>
                                <option value="short-answer">Short Answer</option>
                            </select>
                        </div>

                        <!-- Placeholder for additional fields for multi-choice questions -->
                        <div id="multiChoiceContainer"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" the "btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" form="questionForm">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        // Handle dynamic addition of MCQ fields based on question type selection
        document.getElementById('questionType').addEventListener('change', function() {
            const container = document.getElementById('multiChoiceContainer');
            container.innerHTML = ''; // Clear previous inputs
            if (this.value === 'multi-choice') {
                container.innerHTML = `
                    <div class="mb-3">
                        <label for="numberOfChoices" class="form-label">Number of Choices</label>
                        <input type="number" class="form-control" id="numberOfChoices" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="canShiftAnswers">
                        <label class="form-check-label" for="canShiftAnswers">Can Shift Answers</label>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="isMultiChoices">
                        <label class="form-check-label" for="isMultiChoices">Is Multi-Choice</label>
                    </div>
                    <!-- Dynamic choices inputs -->
                    ${Array.from({length: 4}, (_, index) => `
                    <div class="row mb-2">
                        <div class="col-md-4">
                            <select class="form-select" required>
                                <option value="">Order</option>
                                <option value="a">A</option>
                                <option value="b">B</option>
                                <option value="c">C</option
                                <option value="d">D</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Choice Text" required>
                        </div>
                        <div class="col-md-2">
                            <input type="checkbox" class="form-check-input">
                            <label class="form-check-label">Correct</label>
                        </div>
                    </div>
                    `).join('')}
                `;
            }
        });
    </script>

    <script>
        function updateQuestionForm() {
            const questionType = document.getElementById('questionType').value;
            const mcqOptions = document.getElementById('mcqOptions');
            const choiceInputs = document.getElementById('choiceInputs');

            if (questionType === 'MCQ') {
                mcqOptions.style.display = 'block';
                generateMCQInputs();
            } else {
                mcqOptions.style.display = 'none';
                choiceInputs.innerHTML = ''; // Clear previous inputs
            }
        }

        function generateMCQInputs() {
            const choiceInputs = document.getElementById('choiceInputs');
            choiceInputs.innerHTML = ''; // Clear previous inputs

            const numberOfChoices = document.getElementById('numberOfChoices').value || 4; // Default to 4 choices if not specified
            for (let i = 0; i < numberOfChoices; i++) {
                choiceInputs.innerHTML += `
                <div class="choice-container">
                    <div class="form-outline flex-fill mb-2">
                        <input type="text" id="choiceText${i}" class="form-control" placeholder="Choice ${String.fromCharCode(65 + i)}" required />
                        <label class="form-label" for="choiceText${i}">Choice ${String.fromCharCode(65 + i)}</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="isCorrect${i}">
                        <label class="form-check-label choice-label" for="isCorrect${i}">Correct</label>
                    </div>
                </div>
            `;
            }
        }

        function submitQuestion() {
            // Implement submission logic here
            console.log('Submitting question');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/courses/show assignment2.blade.php ENDPATH**/ ?>