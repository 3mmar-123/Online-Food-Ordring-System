<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">
    <style type="text/css">
        #buttn {
            color: #fff;
            background-color: #ff3300;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div style=" background-image: url('<?php echo e(asset('img/fields/heroFOS.webp')); ?>');">


        <div class="pen-title">
            <
        </div>

        <div class="module form-module">
            <div class="toggle">

            </div>
            <div class="form">
                <h2>Login to your account</h2>
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="email" placeholder="Username" name="email"/>
                    <input type="password" placeholder="Password" name="password"/>
                    <input type="submit" id="buttn" name="submit" value="Login"/>
                </form>
            </div>

            <div class="cta">Not registered?<a href="<?php echo e(route('register')); ?>" style="color:#f30;"> Create an account</a>
            </div>
        </div>


        <div class="container-fluid pt-3">
            <p></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/auth/login.blade.php ENDPATH**/ ?>