<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hero'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-sm justify-content-center d-flex min-vh-100 flex-column align-items-center ">
        <div>
            <a href="<?php echo e(route('home')); ?>">

            </a>
        </div>
        <div class="w-100 mt-2 max-w-md border-primary border-1  border p-2">
            <form action="<?php echo e(route('login')); ?>" method="POST" novalidate>
                <?php echo csrf_field(); ?>
                <div class="text-center">
                    <h1 CLASS="mb-2">Log-in </h1>
                </div>
                <div class="form-outline mb-4">
                    <input type="email" id="email" name="email"
                           value="<?php echo e(old('email')); ?>"
                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                    <label class="form-label" for="email">Email</label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-outline mb-4">
                    <input type="password" id="password" name="password"
                           value="<?php echo e(old('password')); ?>"
                           class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                    <label class="form-label" for="password">Password</label>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" value="" name="remember" id="remember" checked/>
                    <label class="form-check-label" for="remember"> Remember me </label>
                </div>

                <div class="row">
                    <div class="col d-flex justify-content-center">
                        <p><a href="<?php echo e(route('password.request')); ?>">Forgot password?</a></p>
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary btn-block mb-4">Login</button>
                    </div>
                </div>
                <!-- Register buttons -->
                <div class="text-center">
                    <p>Not a member? <a href="<?php echo e(route('register')); ?>">Register</a></p>









                    <span class="accent-light">Contact Us </span>
                    <a href="http://instagram.com/_u/maddweb_4"
                        data-mdb-ripple-init type="button" style="vertical-align: unset;"
                            class="btn btn-secondary btn-secondary-fab btn-floating mx-1">
                        <i class="fab fa-2x  fa-instagram"></i>
                    </a>

                    <a href= "mailto: maddwep3@email.com"
                       data-mdb-ripple-init type="button"
                       class="btn btn-secondary btn-secondary-fab btn-floating mx-1">
                        <i class="fab fa-2x fa-google-plus-g"></i>
                    </a>

                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/auth/login.blade.php ENDPATH**/ ?>