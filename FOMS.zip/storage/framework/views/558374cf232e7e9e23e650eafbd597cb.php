<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-5 mt-5">
        <div class="row g-5">
            <div class="col-12 mb-4">
                <input type="text" id="courseFilter" class="form-control" placeholder="Filter courses...">
            </div>
        </div>
        <div class="row" id="coursesRow">
            <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4 course-container mb-4 d-flex">
                    <div class="card hover-shadow flex-fill">
                        <img class="card-img-top" src="<?php echo e(asset($course->img_path ?? 'img/logo1.webp')); ?>"
                             alt="Course Image">
                        <div class="card-body searchable-text ">
                            <h5 class="card-title searchable-text"><?php echo e($course->title); ?></h5>
                            <p class="card-text"><?php echo e($course->description); ?></p>
                        </div>
                        <div class="card-footer">
                            <div class="d-flex justify-content-around mb-3 searchable-text">
                                <span class="badge bg-success"><?php echo e($course->category->text); ?></span>
                                <span class="badge bg-success"><?php echo e($course->level->text); ?></span>
                            </div>
                            <div class="d-flex justify-content-around align-items-center mb-3">
                                <div><i class="fas fa-users"></i><?php echo e($course->enrollments_count); ?></div>
                                <p class=" mb-3 course-rate" data-rate="<?php echo e($course->rating/500); ?>"></p>
                            </div>


                            <a href="<?php echo e(route('course.show',$course->id)); ?>" class="btn btn-primary">Go to course</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card-text text-muted">
                    There are no published courses yet please visit this page again later
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>
    <script>
        document.getElementById('courseFilter').addEventListener('input', function (e) {
            const filterText = e.target.value.toLowerCase();
            const courses = document.querySelectorAll('#coursesRow .col-md-6');
            courses.forEach(course => {
                let exists=false;
                course.querySelectorAll('.searchable-text').forEach(function (item) {
                    const title = item.textContent.toLowerCase();

                    if (title.includes(filterText)) {
                        console.log(title)
                        exists=true;
                    }
                })
                console.log(exists)

                if (exists) {
                    course.classList.add('d-flex');
                    course.classList.remove('d-none');
                } else {
                    course.classList.add('d-none');
                    course.classList.remove('d-flex');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/courses/index.blade.php ENDPATH**/ ?>