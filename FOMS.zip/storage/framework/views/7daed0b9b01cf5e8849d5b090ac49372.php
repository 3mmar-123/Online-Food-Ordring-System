<?php $__env->startSection('title'); ?>
    منصة مدد - عرض الطالب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-6 m-5">
			<div class="card">
				<div class="card-header bg-info"><strong>التفاصيل</strong></div>
				<div class="card-body">
					<table class="table">




						<tr>
							<th>الاسم</th>
							<td><?php echo e($student->name); ?></td>
						</tr>
						<tr>
							<th>البريد الإلكتروني</th>
							<td><?php echo e($student->email); ?></td>
						</tr>












					</table>
				</div>
				<div class="card-footer">
					<a href="<?php echo e(route('admin.student.edit', $student->id)); ?>" class="btn btn-info">تحرير</a>
					<a href="<?php echo e(route('admin.student.index')); ?>" class="btn btn-danger">عوده</a>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/admin/students/show.blade.php ENDPATH**/ ?>