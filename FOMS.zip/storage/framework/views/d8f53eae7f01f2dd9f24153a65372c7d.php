<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <div class="container-fluid">
            <div class="card card-outline-primary">


                <div class="card-header">
                    <h4 class="m-b-0 text-white">Delivery Agents <a class="btn btn-outline-secondary w-auto pull-right bg-primary new-agent"><i class="fa fa-add"></i> New</a></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive m-t-40">
                        <table id="myTable" class="table table-bagented table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo e($loop->index+1); ?></th>
                                    <th><?php echo e($agent->user->name); ?></th>
                                    <td><?php echo e($agent->user->phone); ?></td>
                                    <td><?php echo e($agent->user->email); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($agent->status?'danger':'success'); ?>">
                                            <?php echo e($agent->status?'Busy':'Available'); ?>

                                        </span></td>

                                    <td>

                                        <div class="btn-group btn-sm">
                                            <a href="#" class="btn btn-primary edit_agent" data-id="<?php echo e($agent->id); ?>"
                                               >Edit
                                            </a>
                                            <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item agent-btn assign-order" href="javascript:" data-id = '<?php echo e($agent->id); ?>' data-op="ao">Assign Order</a>
                                                <div class="dropdown-divider" ></div>
                                                <a class="dropdown-item  agent-btn daily-tasks" href="javascript:void(0)" data-id = '<?php echo e($agent->id); ?>' data-op="dt">Daily Delivers</a>
                                                <a class="dropdown-item agent-btn text-danger delete-agent" href="javascript:void(0)" data-id = '<?php echo e($agent->id); ?>' data-op="d">Delete</a>
                                            </div>
                                        </div>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No Agents</td>
                                </tr>

                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        const agentEditURL='<?php echo e(route('agent.edit','__id__')); ?>'
        const agentOPURL='<?php echo e(route('agent.operations')); ?>'
        $('.new-agent').click(function () {
            uni_modal('Add Agent', '<?php echo e(route('agent.create')); ?>');
        })
        $('.edit_agent').click(function () {
            uni_modal('Update Agent Info', agentEditURL.replace('__id__',this.dataset.id));
        })
        $('.agent-btn').click(function () {
            uni_modal('', '<?php echo e(route('agent.operations')); ?>'+'?id='+this.dataset.id+'&op='+this.dataset.op);
        })
        $('.change-status').click(function () {
            start_load()
            $.ajax({
                url: '{route("owner.change-agent-status")}}',
                method: 'POST',
                data: {id: this.dataset.id, sid: this.dataset.value, _token: '<?php echo e(csrf_token()); ?>'},
                success: function (resp) {
                    if (resp) {
                        notify(resp.status || "success", resp.message || "Process completed")
                        setTimeout(function () {
                            location.reload()
                        }, 1500)
                    }
                },
                error: function (xhr, status, message) {
                    console.log(xhr)
                    end_load()
                    notify('error', "Err " + status + " " + message)
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/owner/agents.blade.php ENDPATH**/ ?>