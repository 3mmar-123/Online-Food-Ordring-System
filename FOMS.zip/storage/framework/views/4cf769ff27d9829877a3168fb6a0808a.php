<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- شعار العلامة التجارية -->
    <a href="" class="brand-link text-center">
        <span
            class="brand-text font-weight-bold"><?php echo e(Auth::user()->role_id == 1 ? 'لوحة الإدارة' : 'لوحة التحكم الخاصة بالمستخدم'); ?></span>
    </a>

    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
            </div>
            <div class="info">
            </div>
        </div>

        <!-- قائمة الشريط الجانبي -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if(Auth::user()->role_id == 1 ): ?>
                    <li class="nav-item has-treeview active">
                        <a href="<?php echo e(route('dashboard')); ?>"
                           class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                            <i class="fas fa-tachometer-alt"></i>
                            <p class="ml-2">
                                لوحة التحكم
                            </p>
                        </a>
                    </li>
                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('admin.users.index')); ?>"
                           class="nav-link <?php echo e(Request::is('admin/users*') ? 'active' : ''); ?>">
                            <i class="fas fa-chart-area"></i>
                            <p class="ml-2">
                                المستخدمين
                            </p>
                        </a>
                    </li>
                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('admin.list')); ?>"
                           class="nav-link <?php echo e(Request::is('admin/list') ? 'active' : ''); ?>">
                            <i class="fa fa-list" aria-hidden="true"></i>
                            <p class="ml-2">
                                قائمة الإدارة
                            </p>
                        </a>
                    </li>

                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('admin.teacher.index')); ?>"
                           class="nav-link <?php echo e(Request::is('admin/teacher*') ? 'active' : ''); ?>">
                            <i class="fas fa-chart-area"></i>
                            <p class="ml-2">
                                المعلمين
                            </p>
                        </a>
                    </li>
                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('admin.student.index')); ?>"
                           class="nav-link <?php echo e(Request::is('admin/student*') ? 'active' : ''); ?>">
                            <i class="fas fa-atlas"></i>
                            <p class="ml-2">
                                الطلاب
                            </p>
                        </a>
                    </li>
                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('admin.course.index')); ?>"
                           class="nav-link <?php echo e(Request::is('admin/course*') ? 'active' : ''); ?>">
                            <i class="fa fa-info-circle" aria-hidden="true"></i>
                            <p class="ml-2">
                                الكورسات
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- /.قائمة الشريط الجانبي -->
    </div>
    <!-- /.الشريط الجانبي -->
</aside>
<?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/layouts/backend/inc/sidebar.blade.php ENDPATH**/ ?>