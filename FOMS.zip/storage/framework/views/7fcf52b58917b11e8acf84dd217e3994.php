<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('libs/fontawesome-6.4.0/css/brands.css.css')); ?>">
    <style>
        .rating-star {
            cursor: pointer;
            font-size: 2em;
            color: #ffdd00; /* Star color */
        }

        .rating-star.checked {
            color: #ffa500; /* Checked star color */
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Choose us Start -->
    <div class="container py-5">

        <!-- Course Detail Card -->
        <div class="card mb-4">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo e(asset($course->img_path??'img/logo1.webp')); ?>" alt="Course Image"
                         class="img-fluid rounded-start"
                         style="object-fit: cover; height: 100%;">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo e($course->title); ?>

                            <?php if($is_owner): ?>
                                <a data-bs-toggle="modal" class="float-end"
                                   data-bs-target="#updateCourseModal">
                                    <i class="text-success fa-sharp fa-solid fa-edit"></i>
                                </a>
                            <?php endif; ?>
                        </h2>
                        <?php if($is_owner): ?>
                            <div class="modal modal-lg fade" id="updateCourseModal" tabindex="-1"
                                 aria-labelledby="createCourseModalLabel" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="createCourseModalLabel">Update Course</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('course.update',$course->id)); ?>"
                                                  id="createCourseForm"
                                                  method="POST" enctype="multipart/form-data" novalidate>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="form-outline mb-4">
                                                    <input type="text" id="modalCourseTitle" name="title"
                                                           value="<?php echo e(old('title',$course->title)); ?>"
                                                           class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label" for="modalCourseTitle">Course
                                                        Title</label>
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-outline mb-4">
                                                            <textarea class="form-control" id="modalCourseDescription"
                                                                      name="description"
                                                                      rows="4"><?php echo e(old('descriptiob',$course->description)); ?></textarea>
                                                    <label class="form-label" for="modalCourseDescription">Course
                                                        Description</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <div class="col">
                                                        <div class="form-outline ">
                                                            <select class="form-select form-control"
                                                                    name="status_id"
                                                                    id="courseStatusSelect">
                                                                <?php $__currentLoopData = $course->status->pluck('text','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option
                                                                        value="<?php echo e($id); ?>" <?php echo e($course->status_id==$id?'selected':''); ?>><?php echo e($title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <label class="form-label select-label active"
                                                                   for="courseCategorySelect">Course Status</label>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-outline ">
                                                            <select class="form-select form-control"
                                                                    name="category_id"
                                                                    id="courseCategorySelect">
                                                                <?php $__currentLoopData = $course->category->pluck('text','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option
                                                                        value="<?php echo e($id); ?>" <?php echo e($course->category_id==$id?'selected':''); ?>><?php echo e($title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <label class="form-label select-label active"
                                                                   for="courseCategorySelect">Select Course
                                                                Category</label>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-outline ">
                                                            <select class="form-select form-control"
                                                                    name="level_id"
                                                                    id="courseLevelSelect">
                                                                <?php $__currentLoopData = $course->level->pluck('text','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option
                                                                        value="<?php echo e($id); ?>" <?php echo e($course->level_id==$id?'selected':''); ?>><?php echo e($title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                            <label class="form-label select-label active"
                                                                   for="courseCategorySelect">Select Course
                                                                Level</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-4">
                                                    <label class="form-label" for="img_path">Course Image</label>
                                                    <input type="file" class="form-control" name="img_path"
                                                           id="img_path"/>
                                                </div>

                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal" aria-label="Close">Close
                                            </button>
                                            <button type="submit" form="createCourseForm"
                                                    class="btn btn-primary">Save changes
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <p class="badge bg-primary mb-2"><?php echo e($course->level->text); ?></p>
                        <p class="badge bg-primary mb-2"><?php echo e($course->status->text); ?></p>
                        <p class="card-text"><?php echo e($course->description); ?>.</p>
                        <p class="card-text"><i class=" fas fa-users"></i> Enrolled
                            Students: <?php echo e($course->enrollments_count); ?></p>
                        <hr>

                        <h5>Course Rating</h5>
                        <div class="card-text">
                            <span class="course-rate" data-rate="<?php echo e($course->rating/100); ?>"></span>
                            <?php if($have_enrollment): ?>
                                <a type="button" class="link-primary nav-item" data-bs-toggle="modal"
                                   data-bs-target="#ratingModal">
                                    Rate Course
                                </a>
                                <div class="modal fade" id="ratingModal" tabindex="-1"
                                     aria-labelledby="ratingModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="ratingModalLabel">Rate this Course</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="rating">
                                                    <i class="rating-star far fa-star" data-value="1"></i>
                                                    <i class="rating-star far fa-star" data-value="2"></i>
                                                    <i class="rating-star far fa-star" data-value="3"></i>
                                                    <i class="rating-star far fa-star" data-value="4"></i>
                                                    <i class="rating-star far fa-star" data-value="5"></i>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                                <button type="button" class="btn btn-primary">Submit Rating</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endif; ?>
                        </div>
                        <?php if($have_enrollment): ?>
                            <?php if($enrollment->status_id==3): ?>
                                <a href="#"
                                   class="btn btn-primary">Achievement <?php echo e($enrollment->final_grade); ?>%</a>

                            <?php else: ?>
                                <a href="<?php echo e(route('lesson.show',\Illuminate\Support\Facades\Auth::user()->courses->where('course_id',$course->id)->first()->last_lesson_id)); ?>"
                                   class="btn btn-primary">Continue</a>
                            <?php endif; ?>


                        <?php elseif(Auth::user()&&Auth::user()->role_id==3): ?>
                            <a href="<?php echo e(route('course.enroll',$course->id)); ?>" class="btn btn-primary">Enroll in
                                Course</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="card-title mb-0">Course Modules</h3>
                    <?php if($is_owner): ?>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#createModuleModal">
                            <i class="fas fa-plus-circle"></i> Create New Module
                        </button>
                        <div class="modal modal-lg fade" id="createModuleModal" tabindex="-1"
                             aria-labelledby="createModuleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="createModuleModalLabel">Create New Module</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('module.store')); ?>" id="createModuleForm"
                                              method="POST"
                                              novalidate>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>"/>
                                            <div class="row">
                                                <div class="col-3">
                                                    <div class="form-outline ">
                                                        <input type="number" id="modalModuleOrder" name="order"
                                                               value="<?php echo e($course->modules->max('order')+1); ?>"
                                                               min="1"
                                                               class="form-control  <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                        <label class="form-label" for="modalModuleOrder">Module
                                                            Order</label>
                                                        <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-outline mb-4">
                                                        <input type="text" id="modalModuleTitle" name="title"
                                                               value="<?php echo e(old('title')); ?>"
                                                               class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                        <label class="form-label" for="modalModuleTitle">Module
                                                            Title</label>
                                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-outline mb-4">
                                            <textarea class="form-control" id="modalCourseDescription"
                                                      name="description"
                                                      rows="4"></textarea>
                                                <label class="form-label" for="modalCourseDescription">Module
                                                    Description</label>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" form="createModuleForm" class="btn btn-primary">Create
                                            Module
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="accordion" id="courseModulesAccordion">
                    <?php $__currentLoopData = $course->modules()->orderBy('order')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <div class="accordion-header d-flex " id="headingModule<?php echo e($loop->index+2); ?>">

                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseModule<?php echo e($loop->index+2); ?>" aria-expanded="true"
                                        aria-controls="collapseModule<?php echo e($loop->index+2); ?>">
                                    <?php echo e("Module ".$module->order.": ".$module->title); ?>

                                    <?php if($have_enrollment): ?>
                                        <span
                                            class="ms-4 text-success"><?php echo e(($module_order>$module->order? $module->lessons_count:($module_order==$module->order?$lesson_order:'0' )).'/'.$module->lessons_count); ?></span>
                                    <?php endif; ?>
                                </button>
                                <?php if($is_owner): ?>
                                    <div class="p-3  align-baseline">
                                        <a class="btn  p-1 bg-transparent link-danger"
                                           onclick="showConfirmAlert('<?php echo e(route('module.destroy',$module->id)); ?>')">
                                            <i class="fa fa-trash"></i></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div id="collapseModule<?php echo e($loop->index+2); ?>" class="accordion-collapse collapse show"
                                 aria-labelledby="headingModule<?php echo e($loop->index+2); ?>"
                                 data-bs-parent="#courseModulesAccordion">
                                <div class="accordion-body">
                                    <ul class="list-group list-group-flush">
                                        <?php $__currentLoopData = $module->lessons()->orderBy('order')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php if($module_order>$module->order||($module_order==$module->order&&$lesson_order>$lesson->order)): ?>
                                                    <a
                                                        class="text-success fa-solid fa-light fa-check"></a>
                                                <?php endif; ?>
                                                <a href="<?php echo e($have_enrollment||$is_owner? route('lesson.show',$lesson->id):'#'); ?>"
                                                   class="link-dark hover-shadow"><?php echo e("Lesson ".$module->order.".".$lesson->order.": ".$lesson->title); ?></a>
                                                <?php if($is_owner): ?>
                                                    <a class="btn p-1 bg-transparent float-end link-danger"
                                                       onclick="showConfirmAlert('<?php echo e(route('lesson.destroy',$lesson->id)); ?>')">
                                                        <i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($is_owner): ?>
                                            <li class="list-group-item  align-items-center">
                                                <!-- Add New Lesson Button (within each module's section for demonstration) -->
                                                <button type="button" class="btn btn-success btn-create-lesson btn-sm"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#createLessonModal"
                                                        data-order="<?php echo e($module->lessons->max('order')+1); ?>"
                                                        data-module="<?php echo e($module->id); ?>">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <span>Add New Lesson</span>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </div>
    <?php if($is_owner): ?>
        <!-- Create Lesson Modal -->
        <div class="modal fade  " id="createLessonModal" tabindex="-1"
             aria-labelledby="createLessonModalLabel"
            
        >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="createLessonModalLabel">Create
                            New
                            Lesson</h5>
                        <button type="button" class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('lesson.store')); ?>"
                              id="createLessonForm"
                              method="POST"
                              novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="form-outline ">
                                <input type="hidden" id="moduleIdInput" name="module"
                                       class="form-control  <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">

                                <div class="col-3">
                                    <div class="form-outline ">
                                        <input type="number" id="modalLessonOrder"
                                               name="lesson_order"
                                               min="1"
                                               class="form-control active  <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                        <label class="form-label "
                                               for="modalLessonOrder">Order</label>
                                        <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-outline ">
                                        <select class="form-select form-control" name="lesson_type"
                                                id="lessonTypeSelect">
                                            <?php $__currentLoopData = $lessonTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>"><?php echo e($title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <label class="form-label select-label"
                                               for="lessonTypeSelect">Type</label>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-outline mb-4">
                                        <input type="text" id="modalLessonTitle"
                                               name="lesson_title"
                                               value="<?php echo e(old('lesson_title')); ?>"
                                               class="form-control <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                        <label class="form-label"
                                               for="modalLessonTitle">Lesson
                                            Title</label>
                                        <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-outline mb-4">
                            <textarea class="form-control"
                                      id="modalLessonDescription"
                                      name="lesson_description"
                                      rows="4">
                            </textarea>
                                <label class="form-label"
                                       for="modalLessonDescription">Lesson
                                    Description</label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">Cancel
                        </button>
                        <button type="submit" form="createLessonForm"
                                class="btn btn-primary">Create Lesson
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        <?php if($have_enrollment==true): ?>
        const stars = document.querySelectorAll('.rating-star');
        stars.forEach(star => {
            star.addEventListener('click', () => {
                removeRating();
                star.classList.add('checked');
                star.classList.replace('far', 'fas'); // Change to filled star

                // Add the checked class to all previous stars
                let previousStar = star.previousElementSibling;
                while (previousStar) {
                    previousStar.classList.add('checked');
                    previousStar.classList.replace('far', 'fas'); // Change to filled star
                    previousStar = previousStar.previousElementSibling;
                }
            });
        });

        function removeRating() {
            stars.forEach(star => {
                star.classList.remove('checked');
                star.classList.replace('fas', 'far'); // Change back to empty star
            });
        }

        document.querySelector('#ratingModal .btn-primary').addEventListener('click', () => {
            let ratingValue = 0;
            stars.forEach(star => {
                if (star.classList.contains('checked')) {
                    ratingValue = star.getAttribute('data-value');
                }
            });
            $.ajax({
                url: '<?php echo e(route('course.rating')); ?>',
                type: 'POST',
                data: {
                    _token: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    courseId: <?php echo e($course->id); ?>,
                    rating: ratingValue
                },
                success: function (responseData) {

                    console.log(responseData);
                    showToast(responseData.status || 'نجح', responseData.message || 'updating successes')
                    if (responseData.reload) {
                        location.reload();
                    } else if (responseData.route) {
                        sessionStorage.setItem(responseData.status, responseData.message);
                        location.href = responseData.route;

                    }

                    if (responseData.error || responseData.status == "error") {
                        console.error('errors', responseData);
                        showError(`<p>*${responseData.message || responseData.responseJSON?.message}<br/> ${responseData.error?.xdebug_message || responseData.responseText}`);
                    }
                    if (responseData.errors) {
                        const errors = responseData.errors;
                        for (const fieldName in errors) {
                            showError(`<p>*${fieldName}: ${errors[fieldName]} </p><br/>`);
                        }

                    }

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.error('Request failed:', jqXHR, textStatus, errorThrown);
                    showToast('فشل', jqXHR.message || jqXHR.responseJSON?.message || jqXHR.responseText || 'deleting failed');
                    showError(jqXHR.responseText || jqXHR.message || jqXHR);
                }
            });

            // Here you would send the ratingValue to your server
            // using an AJAX request or form submission
        });
        <?php else: ?>
        $('.btn-create-lesson').on('click', function (e) {
            $('#modalLessonOrder').val($(this).data('order'));
            $('#modalLessonOrder').change();
            $('#moduleIdInput').val($(this).data('module'));
        });
        <?php endif; ?>
        SearchBox.createSelectDropdown('.form-select:not(.initialized)');

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/courses/show.blade.php ENDPATH**/ ?>