<?php $__env->startSection('title'); ?>
    منصة مدد - لوحة التحكم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row pt-5">
            <h2 class="m-auto" style="font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif"><strong>لوحة الإدارة</strong></h2>
        </div>
    </div>
    <div class="main-section">
        <div class="dashbord dashbord-skyblue">
            <div class="icon-section">
                <i class="fas fa-chalkboard-teacher"></i><br>
                المستخدمين
                <p><?php echo e($users->count()); ?></p>
            </div>
            <div class="detail-section">
                <a href="<?php echo e(route('admin.users.index')); ?>">مزيد من المعلومات </a>
            </div>
        </div>
        <div class="dashbord dashbord-blue">
            <div class="icon-section">
                <i class="fa fa-user" aria-hidden="true"></i><br>
                الإدارة
                <p>1</p>
            </div>
            <div class="detail-section">
                <a href="<?php echo e(route('admin.list')); ?>">مزيد من المعلومات </a>
            </div>
        </div>

        <div class="dashbord dashbord-green">
            <div class="icon-section">
                <i class="fas fa-chalkboard-teacher"></i><br>
                المعلمين
                <p><?php echo e($teachers->count()); ?></p>
            </div>
            <div class="detail-section">
                <a href="<?php echo e(route('admin.teacher.index')); ?>">مزيد من المعلومات </a>
            </div>
        </div>
        <div class="dashbord dashbord-orange">
            <div class="icon-section">
                <i class="fa fa-info-circle" aria-hidden="true"></i><br>
                الطلاب
                <p><?php echo e($students->count()); ?></p>
            </div>
            <div class="detail-section">
                <a href="<?php echo e(route('admin.student.index')); ?>">مزيد من المعلومات </a>
            </div>
        </div>
        <div class="dashbord">
            <div class="icon-section">
                <i class="fas fa-book"></i><br>
                الكورسات
                <p><?php echo e($courses->count()); ?></p>
            </div>
            <div class="detail-section">
                <a href="<?php echo e(route('admin.course.index')); ?>">مزيد من المعلومات </a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>