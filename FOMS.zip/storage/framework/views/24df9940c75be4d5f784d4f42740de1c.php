<header id="header" class="header-scroll top-header headrom">
    <nav class="navbar navbar-dark">
        <div class="container">
            <button class="navbar-toggler hidden-lg-up" type="button" data-bs-toggle="collapse"
                    data-bs-target="#mainNavbarCollapse">&#9776;
            </button>
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img class="img-rounded"
                     src="<?php echo e(asset('assets/images/food-mania-logo.png')); ?>"
                     alt=""> </a>
            <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                <ul class="nav navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('home')); ?>">Home <span
                                class="sr-only">(current)</span></a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('customer.restaurants')); ?>">Restaurants
                            <span class="sr-only"></span></a></li>
                    <?php if(auth()->id()): ?>
                        <?php if(auth()->user()->role=="owner"): ?>
                            <li class="nav-item"><a href="<?php echo e(route('owner.dashboard')); ?>" class="nav-link active">Your
                                    Dashboard</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a href="<?php echo e(route('customer.orders')); ?>" class="nav-link active">Your
                                    Orders</a></li>
                        <?php endif; ?>
                        <li class="nav-item"><a href="<?php echo e(route('logout')); ?>" class="nav-link active">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="nav-link active">Login</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('register')); ?>" class="nav-link active">Signup</a></li>
                    <?php endif; ?>
                </ul>

            </div>
        </div>
    </nav>

</header>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/layouts/header.blade.php ENDPATH**/ ?>