<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <title>Food Ordering </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
    <meta content="" name="description">
    <!-- Favicon -->
    <link href="<?php echo e(asset('css/mdb6-2.css')); ?>" rel="stylesheet">


    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/animsition.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/iziToast.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/mdb5-customized.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/stylev2.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap');
    </style>
    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="home">
<?php echo $__env->make('component.nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- content yield -->
<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/iziToast.js')); ?>"></script>
<?php echo $__env->make('component.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script src="<?php echo e(asset('assets/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/animsition.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-slider.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/headroom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/foodpicky.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jsv2.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/layouts/main.blade.php ENDPATH**/ ?>