<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating Card</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .card {
            width: 300px;
            height: 400px;
            perspective: 1000px;
            position: relative;
        }

        .card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.6s ease;
        }

        .card:hover .card-inner {
            transform: rotateY(180deg);
        }

        .card-front,
        .card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-front {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background-color: #fff;
        }

        .card-front img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: absolute;
            z-index: 1;
        }
        .card-front h3 {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: relative;
            z-index: 2;
            padding: 10px 20px;
            background: rgba(0,0,0,0.6);
        }

        .card-back {
            background-color: #fff;
            transform: rotateY(180deg);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            text-align: center;
        }

        .card-back h3 {
            margin: 0 0 10px;
            font-size: 1.5em;
            color: #333;
        }

        .card-back p {
            margin: 0;
            font-size: 1em;
            color: #555;
        }
    </style>
</head>
<body>
<div class="card">

    <div class="card-inner">
        <div class="card-front">
            <img src="https://via.placeholder.com/300x400" alt="Card Image">
            <h3>Card Title</h3>

        </div>
        <div class="card-back">
            <h3>Card Title</h3>
            <p>This is a description that appears when you hover over the card.</p>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/temp.blade.php ENDPATH**/ ?>