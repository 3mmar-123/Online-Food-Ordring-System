<form action="<?php echo e(route('agent.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($agent->id)): ?>
        <input type="hidden" name="aid" value="<?php echo e($agent->id); ?>">
    <?php endif; ?>
    <div class="form-group">
        <label for="example-text-input" class="form-label">Name</label>
        <input class="form-control border border-info" type="text" name="name"
               value="<?php echo e(isset($agent->user)?$agent->user->name:''); ?>"
               id="example-text-input">
    </div>
    <div class="row mt-2">
        <div class="form-outline col-sm-6">
            <label for="exampleInputEmail1" class="form-label">Email</label>
            <input type="text" class="form-control border border-info" name="email"
                   value="<?php echo e(isset($agent->user)?$agent->user->email:''); ?>"
                   id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="form-outline col-sm-6">
            <label for="example-tel-input-3" class="form-label">Phone</label>
            <input class="form-control border border-info" type="text" name="phone"
                   value="<?php echo e(isset($agent->user)?$agent->user->phone:''); ?>"
                   id="example-tel-input-3">
        </div>
    </div>
    <div class="row mt-2">
        <?php if(isset($agent->user)): ?>
            <div class="form-outline col-sm-6">
                <label for="exampleInputPassword1" class="form-label"> New Password</label>
                <input type="password" class="form-control border border-info" name="npassword"
                       placeholder="******************"
                       id="exampleInputPassword1">
            </div>
        <?php else: ?>
            <div class="form-outline col-sm-6">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control border border-info" name="password"
                       placeholder="******************"
                       id="exampleInputPassword1">
            </div>
        <?php endif; ?>

        <div class="form-outline col-sm-6">
            <label for="example-trans-input-3" class="form-label">Transportation</label>
            <input class="form-control border border-info" type="text" name="transportation"
                   value="<?php echo e($agent->transportation??''); ?>"
                   id="example-trans-input-3">
        </div>
    </div>
</form>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/forms/agent-frm.blade.php ENDPATH**/ ?>