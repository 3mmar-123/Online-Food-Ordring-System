<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <!-- Search Bar -->
        <div class="container mt-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <form action="<?php echo e(route('customer.search')); ?>" method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search for restaurants or menus..." value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                </div>



            </div>
        </div>

        <!-- Search Results -->
        <?php if(request('search')): ?>
            <section class="restaurants-page mt-4">
                <div class="container">
                    <h4>Search Results for: <strong><?php echo e(request('search')); ?></strong></h4>
                    <div class="bg-gray restaurant-entry">
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-sm-12 col-md-12 col-lg-8 text-xs-center text-sm-left">
                                    <div class="entry-logo">
                                        <a class="img-fluid" href="<?php echo e(route('customer.menu', $restaurant->id)); ?>">
                                            <img src="<?php echo e(asset($restaurant->logo_url)); ?>" alt="<?php echo e($restaurant->name); ?> logo">
                                        </a>
                                    </div>
                                    <!-- Entry Description -->
                                    <div class="entry-dscr">
                                        <h5>
                                            <a href="<?php echo e(route('customer.menu', $restaurant->id)); ?>"><?php echo e($restaurant->name); ?></a>
                                        </h5>
                                        <span><?php echo e($restaurant->address); ?></span>
                                    </div>
                                    <?php if($restaurant->menus->isNotEmpty()): ?>
                                        <h6>Matching Menus:</h6>
                                        <ul>
                                            <?php $__currentLoopData = $restaurant->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($menu->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p>No matching menus found.</p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-sm-12 col-md-12 col-lg-4 text-xs-center">
                                    <div class="right-content bg-white">
                                        <div class="right-review">
                                            <a href="<?php echo e(route('customer.menu', $restaurant->id)); ?>" class="btn theme-btn-dash">View Menu</a>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-center">No restaurants or menus found for your search.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/restaurant/search.blade.php ENDPATH**/ ?>