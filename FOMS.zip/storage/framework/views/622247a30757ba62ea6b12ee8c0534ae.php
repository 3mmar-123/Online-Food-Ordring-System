<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locate User</title>
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <!-- Leaflet LocateControl CSS -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.83.0/dist/L.Control.Locate.min.css" />
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <!-- Leaflet LocateControl JS -->
    <script src="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.83.0/dist/L.Control.Locate.min.js"></script>

    <style>
        #map {
            height: 500px;
            width: 100%;
        }
    </style>
</head>
<body>
<div>
    <h1>Find Your Location</h1>
    <div id="map"></div>
    <form id="locationForm" method="POST" action="<?php echo e(route('location.save')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="latitude" id="latitude">
        <input type="hidden" name="longitude" id="longitude">
        <button type="submit">Save Location</button>
    </form>
</div>

<script>
    // Default location (fallback if user denies access or an error occurs)
    const defaultLocation = { lat: 51.505, lng: -0.09 };

    // Initialize the map variable
    let map = null;
    let marker = null;

    // Function to initialize the map with a given location
    function initializeMap(lat, lng) {
        if (!map) {
            // Initialize map if it's not already initialized
            map = L.map('map').setView([lat, lng], 13);

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
            }).addTo(map);

            // Add a draggable marker
            marker = L.marker([lat, lng], { draggable: true }).addTo(map);

            // Update hidden inputs when the marker is moved
            marker.on('moveend', function (e) {
                const position = e.target.getLatLng();
                updateLatLng(position.lat, position.lng);
            });
        } else {
            // If the map is already initialized, just update the view and marker
            map.setView([lat, lng], 13);
            marker.setLatLng([lat, lng]);
            // Add the Leaflet LocateControl button to the map

        }
        const locateControl = L.control.locate({
            position: 'topright',    // Position the button at the top-right corner of the map
            drawCircle: false,       // Disable the circle around the location
            follow: true,            // Automatically follow the user's location
            setView: true,           // Center the map when the location is found
            keepCurrentZoomLevel: true, // Keep the zoom level fixed
        }).addTo(map);

        // Automatically trigger location search on map load
        locateControl.start();
        // Update the hidden form inputs
        updateLatLng(lat, lng);
    }

    // Function to update hidden inputs
    function updateLatLng(lat, lng) {
        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;
    }

    // Function to get the user's location
    function getUserLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function (position) {
                    const { latitude, longitude } = position.coords;
                    initializeMap(latitude, longitude); // Use user's location
                },
                function () {
                    alert('Unable to retrieve your location. Using default location.');
                    initializeMap(defaultLocation.lat, defaultLocation.lng); // Use fallback location
                },
                {
                    enableHighAccuracy: true, // Request high accuracy
                    timeout: 10000,          // Wait up to 10 seconds
                    maximumAge: 0            // Prevent cached locations
                }
            );
        } else {
            alert('Geolocation is not supported by your browser. Using default location.');
            initializeMap(defaultLocation.lat, defaultLocation.lng); // Use fallback location
        }
    }

    // Initialize the map on page load with geolocation (if available)
    getUserLocation();


</script>
</body>
</html>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/auth/map2.blade.php ENDPATH**/ ?>