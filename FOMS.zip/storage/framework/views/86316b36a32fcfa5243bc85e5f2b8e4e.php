<?php $__env->startSection('title'); ?>
    منصة مدد - إضافة مستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card mt-5">
                    <div class="card-header  bg-dark">
                      <h3 class="card-title float-left"><strong>إضافة مستخدم</strong></h3>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">



                  <?php echo $__env->make('partial.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" enctype="multipart/form-data">
					        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">الاسم:</label>
                            <input type="text" class="form-control" placeholder="أدخل الاسم" id="name" name="name">
                        </div>
                        <div class="form-group">
                            <label for="email">البريد الإلكتروني:</label>
                            <input type="text" class="form-control" placeholder="أدخل البريد الإلكتروني" id="email" name="email" value="">
                        </div>
                        <div class="form-group">
                            <label for="password">كلمة المرور:</label>
                            <input type="password" class="form-control" placeholder="أدخل كلمة المرور" id="password" name="password" value="">
                        </div>
                        <div class="form-group">
                            <label for="role">نوع المستخدم:</label>
                            <select class="form-control" id="role" name="role">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                        <button type="submit" class="btn btn-success">إنشاء</button>
                        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger wave-effect" >عوده</a>
                  </div>


      				</form>


                    </div>

                    <!-- /.card-body -->
                  </div>
                  <!-- /.card -->
            </div>
        </div>
    </div><!-- /.container -->





 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/admin/users/create.blade.php ENDPATH**/ ?>