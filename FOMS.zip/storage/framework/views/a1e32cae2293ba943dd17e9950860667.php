<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/layouts/backend/inc/control-sidebar.blade.php ENDPATH**/ ?>