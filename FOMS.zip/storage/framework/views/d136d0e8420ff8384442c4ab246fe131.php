<?php $__env->startSection('title'); ?>
    منصة مدد - الكورسات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <?php echo $__env->make('partial.successMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card my-5 mx-4">
                    <div class="card-header bg-dark">
                        <h3 class="card-title float-right p-0 m-0"><strong>إدارة الكورسات (<?php echo e($courseCount); ?>)</strong>
                        </h3>
                    </div>
                    <!-- الرأس -->
                    <?php if($courses->count() > 0): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="dataTableId" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>الصورة</th>
                                        <th>العنوان</th>
                                        <th>المعلم</th>
                                        <th>الوصف</th>
                                        <th>القسم</th>
                                        <th>المستوى</th>
                                        <th>الحالة</th>
                                        <th>تاريخ البدء</th>
                                        <th>تاريخ الاكتمال</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img style="height: 60px; width: 100px;" class="img-fluid"
                                                     src="<?php echo e(asset($course->img_path??'img/logo5.jpg')); ?>" alt="صورة">
                                            </td>
                                            <td><?php echo e($course->title); ?></td>
                                            <td><?php echo e($course->teacher?->name?:'غير معروف'); ?></td>
                                            <td><?php echo e($course->description??'بدون'); ?></td>
                                            <td><?php echo e($course->category?->ar_text?:'غير معروف'); ?></td>
                                            <td><?php echo e($course->level?->ar_text?:'غير معروف'); ?></td>
                                            <td><?php echo e($course->status_id); ?></td>

                                            <td><?php echo e($course->start_date??'غير محدد'); ?></td>
                                            <td><?php echo e($course->end_date??'غير محدد'); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.course.show', $course->id)); ?>"
                                                   class="btn btn-success">تفاصيل</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php else: ?>
                        <h2 class="text-center text-info font-weight-bold m-3">لم يتم العثور على كورسات</h2>
                    <?php endif; ?>
                    <div class="pagination ml-3">
                        <?php echo e($courses->links()); ?>

                    </div>
                    <!-- جسم البطاقة -->
                </div>
                <!-- البطاقة -->
            </div>
        </div>
    </div><!-- /.الحاوية -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleDeleteCourse(id) {

            var form = document.getElementById('deleteCourseForm')
            form.action = 'course/' + id
            $('#deleteCourseModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>