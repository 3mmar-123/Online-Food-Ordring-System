<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <title>MADD OLMS</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
    <meta content="" name="description">
    <!-- Favicon -->
    <link href=<?php echo e(asset('img/logo4.jpg')); ?> rel="icon">


    <link href='<?php echo e(asset('libs/animate/animate.min.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('libs/owlcarousel/assets/owl.carousel.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('libs/owlcarousel/assets/owl.theme.default.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('libs/tempusdominus/css/tempusdominus-bootstrap-4.min.css')); ?>' rel="stylesheet"/>
    <link href='<?php echo e(asset('libs/fontawesome-6.4.0/css/all.css')); ?>' rel="stylesheet"/>
    <link href='<?php echo e(asset('libs/fontawesome-6.4.0/css/v4-shims.css')); ?>' rel="stylesheet"/>

    <link href='<?php echo e(asset('css/mdb6-2.css')); ?>' rel="stylesheet">

    <link href='<?php echo e(asset('css/style.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('css/style2.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('css/nav-sub-menu.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('css/app.css')); ?>' rel="stylesheet">
    <link href='<?php echo e(asset('css/select-dropdown.css')); ?>' rel="stylesheet">

    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
<!-- Spinner Start -->
<div id="spinner"
     class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Spinner End -->

<!-- Navbar & Hero Start -->
<div class="container-fluid position-relative p-0">
    <?php echo $__env->yieldContent('nav_bar'); ?>
    <?php echo $__env->yieldContent('hero'); ?>
</div>
<!-- Navbar & Hero End --><!-- Navbar & Hero End -->

<!-- content yield -->
<?php echo $__env->yieldContent('content'); ?>

<div class="server-messages-container">
    <button type="button" class="col-3 btn btn-primary" data-bs-toggle="collapse"
            data-bs-target="#errors-container-collapse">رسائل
    </button>
    <div id="errors-container-collapse" class="collapse" style="background-color:white;right:20px">
        <button type="button" class="btn btn-danger" onclick="clearErrorsContainer()" id="errors-container-clear-btn">
            تفريغ
        </button>
        <div id="errors-container">


        </div>
    </div>
</div>
<!-- Footer Start -->
<?php echo $__env->yieldContent('footer'); ?>
<!-- Footer End -->


<!-- Back to Top -->
<a href="#" class="btn btn-lg border text-primary btn-lg-square back-to-top"><i class="fa fa-angle-up"></i></a>


<!-- JavaScript Libraries -->
<script src="<?php echo e(asset('js/jquery-3.6.4.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
<script src=<?php echo e(asset('libs/wow/wow.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/easing/easing.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/waypoints/waypoints.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/owlcarousel/owl.carousel.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/tempusdominus/js/moment.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/tempusdominus/js/moment-timezone.min.js')); ?>></script>
<script src=<?php echo e(asset('libs/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>></script>
<!-- Template Javascript -->
<script src=<?php echo e(asset('js/main.js')); ?>></script>
<script src=<?php echo e(asset('js/app.js')); ?>></script>
<script src=<?php echo e(asset('js/search-tags.js')); ?>></script>

<?php echo $__env->yieldContent('scripts'); ?>
<script>
    <?php if(session('success')): ?>
    showToast('success', '<?php echo e(\Illuminate\Support\Facades\Session::pull('success')); ?>');
    <?php endif; ?>

    <?php if(session('error')): ?>
        let error='<?php echo e(\Illuminate\Support\Facades\Session::pull('error')); ?>'
    showToast('error', error);
    showError(error)
    <?php endif; ?>
    <?php if($errors&&$errors->any()): ?>
    let errors='';
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    errors+='<?php echo e($errors->forget($key)); ?>\n';
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    showToast('error', errors);
    showError(errors)
    <?php endif; ?>
    formControlsSetUp();
    </script>
<script>
    function getStarRating(rating) {
        let ratingHtml = '';
        for (let i = 0; i < 5; i++) {
            if (rating >= i + 1) {
                ratingHtml += '<i class="fas fa-star text-warning"></i>'; // full star
            } else if (rating >= i + 0.5) {
                ratingHtml += '<i class="fas fa-star-half-alt text-warning"></i>'; // half star
            } else {
                ratingHtml += '<i class="far fa-star text-warning"></i>'; // empty star
            }
        }
        return ratingHtml;
    }
    document.querySelectorAll('.course-rate:not(.rated)').forEach(function (ratingDiv) {
        console.error(this);
        const rating = parseFloat(ratingDiv.dataset.rate);
        ratingDiv.innerHTML = getStarRating(rating);
        ratingDiv.innerHTML +=` ${rating*100}/500`;
    });

</script>
</body>

</html>
<?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/layouts/main.blade.php ENDPATH**/ ?>