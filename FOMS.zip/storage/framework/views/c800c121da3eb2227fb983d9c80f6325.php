<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item "><span>1</span><a href="#">Choose Restaurant</a></li>
                    <li class="col-xs-12 col-sm-4 link-item"><span>2</span><a href="#">Pick Your favorite food</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>3</span><a href="#">Order and Pay</a></li>
                </ul>
            </div>
        </div>
        <div class="inner-page-hero bg-image" data-image-src="<?php echo e(asset('assets/images/img/res.jpeg')); ?>">
            <div class="container"></div>
        </div>
        <div class="result-show">
            <div class="container">
                <div class="row">
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="card card-outline-primary">
                <div class="card-header">
                    <h4 class="m-b-0 text-white">Menu Order Review</h4>
                </div>
                <div class="card-body">
                    <div class="form">
                        <form id="locationForm" method="POST"
                              action="<?php echo e(route('restaurant.update-profile')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="latitude" id="latitude">
                            <input type="hidden" name="longitude" id="longitude">
                            <div class="row">
                                <div class="form-group col-sm-12">
                                    <label for="example-text-input">Restaurant Name</label>
                                    <input class="form-control" type="text" name="restaurant_name"
                                           id="example-text-input">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="example-phone">Phone</label>
                                    <input class="form-control" type="tel" name="phone"
                                           value="<?php echo e(auth('web')->user()->phone); ?>" id="example-phone">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="example-image">Profile Image</label>
                                    <input class="form-control" type="file" name="image"
                                           id="example-image">
                                </div>
                                <div class="form-group col-sm-12">
                                    <label for="example-address">Your Address</label>
                                    <input class="form-control" type="text" name="address" id="example-address">
                                </div>

                            </div>
                            <div class="form-group col-sm-12">
                                <label for="exampleTextarea">Brief Description</label>
                                <textarea class="form-control" id="exampleTextarea"  name="description" rows="3"></textarea>
                            </div>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p> <input type="submit" value="Save" name="submit" class="btn theme-btn"> </p>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive m-t-40">
                        <table id="menu-order-table"
                               class="display nowrap table table-hover table-striped table-bordered"
                               cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>Image</th>
                                <th>Dish-Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset($item->menu->image_url)); ?>"
                                             class="img-responsive  radius"
                                             style="max-height:100px;max-width:150px;"/>
                                    </td>
                                    <td><?php echo e($item->menu->name); ?></td>
                                    <td><?php echo e($item->menu->description); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->subtotal); ?></td>
                                    <td>
                                        <a href=""
                                           class="btn btn-danger btn-flat btn-addon btn-xs m-b-10"><i
                                                class="fa fa-trash-o" style="font-size:16px"></i></a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">
                                        <center>No Items</center>
                                    </td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" class="text-center">Total</th>
                                <th ><?php echo e($order->orderItems->sum('quantity')); ?></th>
                                <th ><?php echo e($order->total_amount); ?></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/restaurant/checkout.blade.php ENDPATH**/ ?>