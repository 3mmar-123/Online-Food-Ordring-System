<div class="left-sidebar">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li> <a href="<?php echo e(route('owner.dashboard')); ?>"><i class="fa fa-tachometer"></i><span>Dashboard</span></a>
                </li>
                <li class="nav-label">Log</li>
                <li> <a href="<?php echo e(route('menus.index')); ?>"><i class="fa fa-cutlery" aria-hidden="true"></i><span>Menus</span></a></li>
                <li> <a href="<?php echo e(route('owner.orders')); ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span>Orders</span></a></li>


            </ul>
        </nav>

    </div>
</div>
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/layouts/left-sidebar.blade.php ENDPATH**/ ?>