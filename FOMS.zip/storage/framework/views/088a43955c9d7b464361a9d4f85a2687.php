<?php $__env->startSection('styles'); ?>
    <style>
        .question-container {
            margin-top: 20px;
        }

        .edit-icon {
            cursor: pointer;
        }

        .edit-icon:hover {
            cursor: pointer;
            box-shadow: 0 1px 15px 3px rgb(130 82 82 / 16%), 0 10px 20px 2px rgb(105 67 67 / 10%);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <!-- Assignment Details -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <h4 class="card-title"><a href="<?php echo e(route('course.show',$lesson->module->course_id)); ?>"
                                          class="text-primary"><i class="fas fa-arrow-circle-left"></i>
                    </a> <?php echo e($lesson->type->text.":".$lesson->module->course->title); ?>

                    : <?php echo e($lesson->title); ?>

                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#updateLessonModal">
                        <i class="fas fa-edit"></i> Update
                    </button>
                </h4>
                <div class="modal fade" id="updateLessonModal" tabindex="-1"
                     aria-labelledby="updateLessonModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="updateLessonModalLabel">Update Assignment</h5>
                                <button type="button" class="btn-close"
                                        data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('assignment.update')); ?>"
                                      id="updateLessonForm"
                                      method="POST"
                                      novalidate>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="assignment_id"
                                           value="<?php echo e($lesson->content->id); ?>"/>
                                    <div class="row mb-2">
                                        <div class="col-3">
                                            <div class="form-outline ">
                                                <input type="number" id="modalLessonOrder"
                                                       name="lesson_order"
                                                       value="<?php echo e($lesson->order); ?>"
                                                       min="1"
                                                       class="form-control  <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                <label class="form-label"
                                                       for="modalLessonOrder">Order</label>
                                                <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-outline mb-4">
                                                <input type="text" id="modalLessonTitle"
                                                       name="lesson_title"
                                                       value="<?php echo e($lesson->title); ?>"
                                                       class="form-control <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                <label class="form-label"
                                                       for="modalLessonTitle">Title</label>
                                                <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-4">
                                            <div class="form-outline mb-3">
                                                <select class="form-select form-control "
                                                        name="assignment_type" id="assignment_type"
                                                >
                                                    <?php $__currentLoopData = $assignmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            value="<?php echo e($key); ?>" <?php echo e($lesson->content->type_id==$key? 'selected':''); ?>><?php echo e($value); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="assignment_type"
                                                       class="select-label form-label active">Assignment Type</label>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-outline ">
                                                <input type="number" id="quiz_time"
                                                       name="quiz_time"
                                                       value="<?php echo e($lesson->content->available_time); ?>"
                                                       class="form-control  <?php $__errorArgs = ['quiz_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                <label class="form-label"
                                                       for="modalLessonOrder">Quiz Time (in minutes)</label>
                                                <?php $__errorArgs = ['quiz_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-outline ">
                                                <input type="number" id="total_marks"
                                                       name="total_marks"
                                                       value="<?php echo e($lesson->content->total_marks); ?>"
                                                       class="form-control  <?php $__errorArgs = ['total_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                <label class="form-label"
                                                       for="total_marks">Total Marks</label>
                                                <?php $__errorArgs = ['total_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col">
                                            <div class="form-outline mb-3">
                                                <input type="date" class="form-control bootstrap-datetimepicker-widget "
                                                       name="open_date" id="open_date"
                                                >
                                                <label for="open_date" class=" form-label active">Open Date</label>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-outline mb-3">
                                                <input type="date" class="form-control bootstrap-datetimepicker-widget "
                                                       name="close_date" id="close_date">
                                                <label for="close_date" class=" form-label active">Close Date</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-outline mb-4">
                                            <textarea class="form-control" id="modalLessonDescription"
                                                      name="lesson_description"
                                                      rows="4">
                                                <?php echo e($lesson->description); ?>

                                            </textarea>
                                        <label class="form-label"
                                               for="modalLessonDescription">Assignment Details</label>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Cancel
                                </button>
                                <button type="submit" form="updateLessonForm"
                                        class="btn btn-primary">Update Lesson
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <p><strong>Type:</strong> <?php echo e($lesson->content->type->text); ?></p>
                <p><strong>Description:</strong> <?php echo e($lesson->description); ?>.</p>
                <p><strong>Available Time:</strong> <?php echo e($lesson->content->available_time); ?> minutes</p>
                <p><strong>Total Marks:</strong> <?php echo e($lesson->content->total_marks); ?></p>
                <p><strong>Open Date:</strong> <?php echo e($lesson->content->period_start); ?></p>
                <p><strong>Close Date:</strong> <?php echo e($lesson->content->period_end); ?></p>
            </div>
        </div>

        <!-- Questions Section -->
        <div class="card shadow">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Questions</h5>
                <button class="btn btn-primary" id="btnAddQuestion" data-bs-toggle="modal"
                        data-bs-target=" #addQuestionModal"><i
                        class="fas fa-plus"></i> Add Question
                </button>
            </div>

            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $lesson->content->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item question-container" data-question="<?php echo e(json_encode($question)); ?>"
                        data-answers="<?php echo e(json_encode($question->answers)); ?>">
                        <?php echo e($question->text); ?><span
                            class="badge bg-primary float-end"><?php echo e($question->marks); ?> points</span>
                        <ul class="list-group">
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item <?php echo e($answer->is_correct?'text-success':''); ?>"><?php echo e($answer->position.": ".$answer->text); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class=" d-flex w-100 p-2 justify-content-end  float-end">
                            <span class="edit-icon delete-question-btn text-danger me-2 fa-sharp fa-solid fa-trash"
                                  data-bs-toggle="modal"
                                  onclick="showConfirmAlert('<?php echo e(route('question.delete',$question->id)); ?>', '<?php echo e(csrf_token()); ?>' )"
                                  data-question="<?php echo e($question->id); ?>"></span>
                            <span class="edit-icon edit-question-btn  me-3  float-end fas fa-edit"
                                  data-bs-toggle="modal"
                                  data-question="<?php echo e($question->id); ?>"
                                  data-bs-target="#addQuestionModal"></span>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="list-group-item question-container">
                    Which language runs in a web browser?<span
                        class="badge bg-primary float-end">5 points</span>
                    <ul class="list-group">
                        <li class="list-group-item">A: Java</li>
                        <li class="list-group-item">B: C</li>
                        <li class="list-group-item">C: JavaScript</li>
                        <li class="list-group-item">D: Python</li>
                    </ul>
                    <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal"
                          data-bs-target="#addQuestionModal"></span>
                </li>
                <li class="list-group-item question-container">
                    What does HTML stand for?<span
                        class="badge bg-primary float-end">5 points</span>
                    <ul class="list-group">
                        <li class="list-group-item">A: Hyper Text Markup Language</li>
                        <li class="list-group-item">B: Home Tool Markup Language</li>
                        <li class="list-group-item">C: Hyperlinks and Text Markup Language</li>
                    </ul>
                    <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal"
                          data-bs-target="#addQuestionModal"></span>
                </li>
                <li class="list-group-item question-container">
                    What does CSS stand for?<span
                        class="badge bg-primary float-end">5 points</span>
                    <ul class="list-group">
                        <li class="list-group-item bg-info">A: Computer Style Sheets</li>
                        <li class="list-group-item">B: Creative Style Sheets</li>
                        <li class="list-group-item">C: Cascading Style Sheets</li>
                        <li class="list-group-item">D: Colorful Style Sheets</li>
                    </ul>
                    <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal"
                          data-bs-target="#addQuestionModal"></span>
                </li>
                <li class="list-group-item question-container">
                    What is the correct HTML for referring to an external style sheet?<span
                        class="badge bg-primary float-end">5 points</span>
                    <ul class="list-group">
                        <li class="list-group-item">A: <code>&lt;stylesheet&gt;mystyle.css&lt;/stylesheet&gt;</code>
                        </li>
                        <li class="list-group-item">B: <code>&lt;style src="mystyle.css"&gt;</code></li>
                        <li class="list-group-item">C: <code>&lt;link rel="stylesheet" type="text/css"
                                href="mystyle.css"&gt;</code></li>
                    </ul>
                    <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal"
                          data-bs-target="#addQuestionModal"></span>
                </li>
                <li class="list-group-item question-container">
                    Which is the correct syntax for referring to an external script called "xxx.js"?<span
                        class="badge bg-primary float-end">5 points</span>
                    <ul class="list-group">
                        <li class="list-group-item">A: <code>&lt;script href="xxx.js"&gt;</code></li>
                        <li class="list-group-item">B: <code>&lt;script name="xxx.js"&gt;</code></li>
                        <li class="list-group-item">C: <code>&lt;script src="xxx.js"&gt;</code></li>
                    </ul>
                    <span class="edit-icon float-end fas fa-edit" data-bs-toggle="modal"
                          data-bs-target="#addQuestionModal"></span>
                </li>

                <li class="list-group-item question-container">What is the inverse square law? (Answer: Details about
                    the law) <span
                        class="badge bg-primary float-end">5 points</span></li>
                <li class="list-group-item question-container">True or False: Energy is conserved in a closed system.
                    (Answer: True) <span
                        class="badge bg-primary float-end">5 points</span></li>
                <li class="list-group-item question-container">Derive the equation for gravitational force between two
                    masses. (Answer: Mathematical derivation) <span class="badge bg-primary float-end">10 points</span>
                </li>
            </ul>
        </div>

        <!-- Add/Edit Question Modal -->
        <div class="modal fade" id="addQuestionModal" tabindex="-1" aria-labelledby="addQuestionModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addQuestionModalLabel">Add/Edit Question</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="questionForm" method="POST" action="<?php echo e(route('question.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="question_id" id="question_id" value="">
                            <input type="hidden" name="quiz_id" value="<?php echo e($lesson->content->id); ?>">
                            <div class="form-outline mb-3">
                                <input type="text" class="form-control" id="questionText" name="ques_text">
                                <label for="questionText" class="form-label">Question</label>
                            </div>
                            <div class="row">
                                <div class="col">

                                    <div class="form-outline mb-3">
                                        <input type="number" class="form-control" name="ques_marks" id="ques_marks">
                                        <label for="ques_marks" class="form-label">Marks</label>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-outline mb-3">
                                        <select class="form-select form-control " name="ques_type" id="questionType">
                                            <option value="MCQ">Multi-Choice</option>
                                            <option value="TF">True/False</option>
                                            <option value="SA">Short Answer</option>
                                        </select>
                                        <label for="questionType" class="select-label form-label active">Question
                                            Type</label>
                                    </div>
                                </div>
                            </div>
                            <div id="multiChoiceContainer">
                                <div class="row mb-3 ">
                                    <div class="col ">
                                        <div class="form-outline">
                                            <input type="number" class="form-control" name="number_of_choices"
                                                   id="numberOfChoices" value="4">
                                            <label for="numberOfChoices" class="form-label">Number of Choices</label>
                                        </div>
                                    </div>
                                    <div class="col align-content-end">
                                        <div class="form-check-inline">
                                            <input type="checkbox" checked class="form-check-input" name="can_shift"
                                                   id="canShiftAnswers">
                                            <label class="form-check-label" for="canShiftAnswers">Can Shift
                                                Answers</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="checkbox" class="form-check-input" name="hav_multi"
                                                   id="haveMultiChoices">
                                            <label class="form-check-label" for="haveMultiChoices">Have
                                                Multi-Choices</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_1_order"
                                                    name="choices[0][order]">
                                                <option value="a">A</option>
                                                <option value="b">B</option>
                                                <option value="c">C</option>
                                                <option value="d">D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_1_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control"
                                                   id="choice_1_text" name="choices[0][text]">
                                            <label class="form-label" for="choice_1_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"
                                                   id="choice_1_isCorrect" name="choices[0][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_1_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_2_order"
                                                    name="choices[1][order]">
                                                <option value="a">A</option>
                                                <option value="b">B</option>
                                                <option value="c">C</option>
                                                <option value="d">D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_2_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control"
                                                   id="choice_2_text" name="choices[1][text]">
                                            <label class="form-label" for="choice_2_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"
                                                   id="choice_2_isCorrect" name="choices[1][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_2_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_3_order"
                                                    name="choices[2][order]">
                                                <option value="a">A</option>
                                                <option value="b">B</option>
                                                <option value="c">C</option>
                                                <option value="d">D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_3_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control"
                                                   id="choice_3_text" name="choices[2][text]">
                                            <label class="form-label" for="choice_3_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"
                                                   id="choice_3_isCorrect" name="choices[2][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_3_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_4_order"
                                                    name="choices[3][order]">
                                                <option value="a">A</option>
                                                <option value="b">B</option>
                                                <option value="c">C</option>
                                                <option value="d">D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_3_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control"
                                                   id="choice_4_text" name="choices[3][text]">
                                            <label class="form-label" for="choice_4_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"
                                                   id="choice_4_isCorrect" name="choices[3][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_4_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" form="questionForm">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

    </script>
    <script>


        document.getElementById('questionType').addEventListener('change', function () {
            const container = document.getElementById('multiChoiceContainer');
            container.innerHTML = ''; // Clear previous inputs
            if (this.value === 'MCQ') {
                container.innerHTML = `
                                <div class="row mb-3 ">
                                    <div class="col">
                                        <div class="form-outline">
                                            <input type="number" value="4" class="form-control" name="number_of_choices"
                                                   id="numberOfChoices" >
                                            <label for="numberOfChoices" class="form-label">Number of Choices</label>
                                        </div>
                                    </div>
                                    <div class="col align-content-end">
                                        <div class="form-check-inline">
                                            <input type="checkbox" checked class="form-check-input" name="can_shift"
                                                   id="canShiftAnswers">
                                            <label class="form-check-label" for="canShiftAnswers">Can Shift
                                                Answers</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="checkbox" class="form-check-input" name="hav_multi"
                                                   id="haveMultiChoices">
                                            <label class="form-check-label" for="haveMultiChoices">Have
                                                Multi-Choices</label>
                                        </div>
                                    </div>
                                </div>
                    <!-- Dynamic choices inputs -->
                    ${Array.from({length: 4}, (_, index) => `
                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_${index}_order"
                                                    name="choices[${index}][order]" >
                                                <option value="a">A</option>
                                                <option value="b">B</option>
                                                <option value="c">C</option>
                                                <option value="d">D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_${index}_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control"
                                                   id="choice_${index}_text" name="choices[${index}][text]">
                                            <label class="form-label" for="choice_${index}_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"
                                                   id="choice_${index}_isCorrect" name="choices[${index}][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_${index}_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>

                    `).join('')}
                `;
            } else if (this.value === 'TF') {
                container.innerHTML = `
                                 <div class="align-content-end d-flex justify-content-center m-4">
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" checked value="T" name="answer"
                                                   id="answer_true">
                                            <label class="form-check-label" for="answer_true" >True</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" value="F" name="answer"
                                                   id="answer_false">
                                            <label class="form-check-label" for="answer_false">False</label>
                                        </div>
                                    </div>
                    `;
            } else {
                container.innerHTML = `
                                <div class="form-outline m-4">
                                    <textarea id="answer_text" class="form-control" name="answer"></textarea>
                                    <label for="answer_text" class="form-label">Answer</label>
                                </div>
                `;

            }
        });
        document.getElementById('btnAddQuestion').addEventListener('click', function () {
            const container = document.getElementById('multiChoiceContainer');
            document.getElementById('question_id').value = '';
            document.getElementById('questionForm').reset();

        });
        document.querySelectorAll('.edit-question-btn').forEach(function (element) {
            element.addEventListener('click', function () {
                const question = $(this.parentElement.parentElement).data('question');
                const answers = $(this.parentElement.parentElement).data('answers');
                console.log(answers)
                const container = document.getElementById('multiChoiceContainer');
                container.innerHTML = `
                                <div class="row mb-3 ">
                                    <div class="col">
                                        <div class="form-outline">
                                            <input type="number" value="4" class="form-control" name="number_of_choices"
                                                   id="numberOfChoices" >
                                            <label for="numberOfChoices" class="form-label">Number of Choices</label>
                                        </div>
                                    </div>
                                    <div class="col align-content-end">
                                        <div class="form-check-inline">
                                            <input type="checkbox" checked class="form-check-input"
                                                    name="can_shift" value="${question.can_shift_answers}" id="canShiftAnswers">
                                            <label class="form-check-label" for="canShiftAnswers">Can Shift
                                                Answers</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="checkbox" class="form-check-input" name="hav_multi"
                                                   value="${question.multi_choices}" id="haveMultiChoices">
                                            <label class="form-check-label" for="haveMultiChoices">Have
                                                Multi-Choices</label>
                                        </div>
                                    </div>
                                </div>
                    <!-- Dynamic choices inputs -->
                    ${Array.from({length: answers.length}, (_, index) => `
                                <div class="row mb-2">
                                    <div class="col-md-2 ">
                                        <input type="hidden" name="choices[${index}][id]" value="${answers[index].id}">
                                        <div class="form-outline">
                                            <select class="form-select form-control" id="choice_${index}_order"
                                                    name="choices[${index}][order]" >
                                                <option value="a" ${answers[index].position == 'a' ? 'selected' : ''}>A</option>
                                                <option value="b" ${answers[index].position == 'b' ? 'selected' : ''}>B</option>
                                                <option value="c" ${answers[index].position == 'c' ? 'selected' : ''}>C</option>
                                                <option value="d" ${answers[index].position == 'd' ? 'selected' : ''}>D</option>
                                            </select>
                                            <label class="form-label select-label active"
                                                   for="choice_${index}_order">Order</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 ">
                                        <div class="form-outline flex-fill mb-2">
                                            <input type="text" class="form-control" value=" ${answers[index].text}"
                                                   id="choice_${index}_text" name="choices[${index}][text]">
                                            <label class="form-label" for="choice_${index}_text">Choice Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2 align-content-end">
                                        <div class="form-check form-outline">
                                            <input class="form-check-input" type="checkbox"  ${answers[index].is_correct ? 'checked' : ''}
                                                   id="choice_${index}_isCorrect" name="choices[${index}][isCorrect]">
                                            <label class="form-check-label choice-label"
                                                   for="choice_${index}_isCorrect">Correct</label>
                                        </div>
                                    </div>
                                </div>

                    `).join('')}
                `;
                document.getElementById('question_id').value = question.id;
                document.getElementById('questionText').value = question.text;
                document.getElementById('ques_marks').value = question.marks;
                formControlsSetUp();
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/courses/show2.blade.php ENDPATH**/ ?>