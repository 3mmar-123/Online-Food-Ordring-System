<!-- Navbar & Hero Start -->
<nav id="header" class="navbar navbar-expand-lg navbar-light  px-4 px-lg-5 py-3 py-lg-0"
     style="    background-color: #c92800;">
    <button class="navbar-toggler bg-primary white-text" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse">
        <span class="fa fa-bars"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav me-auto py-0">
            <a href="<?php echo e(route('home')); ?>"
               class="nav-item nav-link <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('home')? 'active':''); ?>">Home</a>
            <a href="<?php echo e(route('about')); ?>"
               class="nav-item nav-link <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('about')? 'active':''); ?>">About</a>

            <?php if(!auth()->id()): ?>
                <a href="<?php echo e(route('customer.restaurants')); ?>"
                   class="nav-item nav-link  <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('customer.restaurants')? 'active':''); ?>">Restaurants</a>
            <?php else: ?>
                <?php if(auth()->user()->role=="owner"): ?>
                    <a class="nav-item nav-link" href="<?php echo e(route('owner.dashboard')); ?>" >Your
                        Dashboard</a>
                <?php elseif(auth()->user()->role=="agent"): ?>
                    <a class="nav-item nav-link" href="<?php echo e(route('agent.orders')); ?>" >Your
                        Tasks</a>
                <?php else: ?>
                    <a href="<?php echo e(route('customer.restaurants')); ?>"
                       class="nav-item nav-link  <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('customer.restaurants')? 'active':''); ?>">Restaurants</a>
                    <a class="nav-item nav-link <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('cart.index')? 'active':''); ?>"
                       href="<?php echo e(route('cart.index')); ?>"><span class="badge badge-danger item_count">0</span> <i
                            class="fa fa-shopping-cart"></i> Cart</a>

                    <a class="nav-item nav-link" href="<?php echo e(route('customer.orders')); ?>" >Your
                        Orders</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="navbar-nav">
            <?php if(\Illuminate\Support\Facades\Auth::user()): ?>
                <!-- Notifications -->
                <div class="nav-item dropdown">
                    <a class="nav-link " href="#" id="notificationsDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        <span class="badge badge-danger"><?php echo e(auth()->user()->notifications->count()); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right animated fadeIn" aria-labelledby="notificationsDropdown">
                        <h6 class="dropdown-header">Notifications</h6>
                        <div class="dropdown-divider"></div>
                        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('notification.show',$notification->id)); ?>" class="dropdown-item text-red small">
                                <i class="fa fa-info-circle text-primary"></i> <?php echo e($notification->message); ?>

                                <span class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                            </a>
                            <div class="dropdown-divider"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <a class="dropdown-item text-center text-muted">No new notifications</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link "
                       data-bs-toggle="dropdown"><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></a>
                    <div class="dropdown-menu m-0">
                        <span class="divider-horizontal dropdown-divider"></span>
                        <a title="Logout" class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="text-danger   fa fa-solid fa-sign-out"> </i> <span
                                data-no-translation>Logout</span></a>
                    </div>
                </div>

            <?php else: ?>
                <a title="sign-up" class="nav-item nav-link " href="<?php echo e(route('login')); ?>">
                <span data-no-translation>
                        Sign Up</span></a>
            <?php endif; ?>

        </div>


    </div>
    <aside class="submenu-popup-container">
    </aside>

</nav>

<!-- Navbar & Hero End -->
<?php /**PATH D:\wamp64\www\Laravel\FOMS\resources\views/component/nav_bar.blade.php ENDPATH**/ ?>