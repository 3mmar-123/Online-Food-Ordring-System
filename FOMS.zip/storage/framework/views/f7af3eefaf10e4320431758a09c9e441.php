<?php $__env->startSection('styles'); ?>
    <style>
        .question-container {
            margin-top: 20px;
        }

        .edit-icon {
            cursor: pointer;
        }

        .edit-icon:hover {
            cursor: pointer;
            box-shadow: 0 1px 15px 3px rgb(130 82 82 / 16%), 0 10px 20px 2px rgb(105 67 67 / 10%);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-sm my-5">
        <!-- Assignment Details -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <h4 class="card-title"><a href="<?php echo e(route('course.show',$lesson->module->course_id)); ?>"
                                          class="text-primary"><i class="fas fa-arrow-circle-left"></i>
                    </a> <?php echo e($lesson->module->course->title.":".$lesson->type->text); ?>

                    : <?php echo e($lesson->title); ?>

                    <?php if($is_owner): ?>
                        <i data-bs-toggle="modal"
                           data-bs-target="#updateLessonModal"
                           class="float-end text-success fa-sharp fa-solid fa-edit"></i>
                    <?php endif; ?>
                </h4>
                <div class="row">
                <p class="col"><strong>Type:</strong> <?php echo e($lesson->content->type->text); ?></p>
                <p class="col"><strong>Available Time:</strong> <?php echo e($lesson->content->available_time); ?> minutes</p>
                <p class="col"><strong>Quiz Marks:</strong> <?php echo e($lesson->content->total_marks); ?></p>
                <p class="col"><strong>Close Date:</strong> <?php echo e($lesson->content->period_end); ?></p>
                </div>
                <p><strong>Description:</strong> <?php echo e($lesson->description); ?>.</p>
                <button id="btnStartQuiz" class="btn btn-primary <?php echo e(isset($student_assignment)? 'disabled':''); ?>" ><?php echo e(isset($student_assignment)? $student_assignment->final_grade.'/'.$student_assignment->assignment->total_marks:'Start Quiz'); ?></button>
            </div>
        </div>
        <?php if(isset($student_assignment)): ?>
            <div class="card shadow">
                <div class="card-header">
                    <h5 class="mb-4">Quiz results</h5>
                    <div class="row">
                        <p class="col"><strong>Correct:</strong> <?php echo e($student_assignment->correct_answers_count.'/'.$student_assignment->answers_count); ?></p>
                        <p class="col"><strong>Finish Time:</strong> <?php echo e($student_assignment->time); ?></p>
                        <p class="col"><strong>Marks:</strong> <?php echo e($student_assignment->final_grade); ?></p>
                    </div>
                </div>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $student_assignment->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item question-container">
                            <?php echo e($question->question->text); ?><span
                                class="badge bg-primary float-end"><?php echo e($question->question->marks); ?> points</span>
                            <ul class="list-group">
                                <?php $__currentLoopData = $question->question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item <?php echo e($answer->is_correct ?'text-success':( $question->answer_id==$answer->id? 'text-danger':'')); ?>"><?php echo e($answer->position.": ".$answer->text); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


        <?php else: ?>
            <div class="container-sm d-none" id="quiz-container">
                <div class="card shadow" id="quizModal">
                    <div class="card-header  ">
                        <div class="d-flex justify-content-around">
                            <h5 class="card-title text-muted" id="quesTitle">Question  <span id="progress-count" class="text-success">5/5</span></h5>
                            <span class="text-muted">Time:  <span  id="progress-time" class="text-success">00:00</span></span>
                        </div>
                        <div class="progress d-none  mt-3 mb-3" id="videoUploadProgressParent">
                            <div class="progress-bar progress-bar-animated" role="progressbar"
                                 id="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0"
                                 aria-valuemax="100"></div>
                            <div class="progress-text text-warning">0%</div>
                        </div>
                    </div>
                    <div class="card-body ">
                        <h3 id="quesText"></h3>
                        <div id="quizContent">

                        </div>
                    </div>
                    <div class="card-footer">
                        <button id="nextButton" class="btn btn-primary" onclick="nextQuestion()">Next Question</button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <?php if(!isset($student_assignment)): ?>
        <script>
            var currentQuestionIndex = 0;
            var correctAnswers = 0;
            var questionsCount = 0;
            var time = 0;
            var timerInterval;
            function startTimer() {
                timerInterval = setInterval(function() {
                    time++;
                    var minutes = Math.floor(time / 60);
                    var seconds = time % 60;

                    document.getElementById("progress-time").innerText = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                }, <?php echo e($lesson->content->available_time*60*1000); ?>);
            }

            function stopTimer() {
                clearInterval(timerInterval);
            }
            console.error("tariq")
            $('#btnStartQuiz').on('click', startQuiz)
            function startQuiz() {
                console.log(this)
                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(route('quiz.start',$lesson->content->id)); ?>',
                    success: function (data) {
                        console.log(data);
                        questionsCount=data.count;
                        time=0;
                        currentQuestionIndex = 1;
                        correctAnswers = 0;
                        $('#videoUploadProgressParent').removeClass('d-none');
                        $('#quiz-container').removeClass('d-none');
                        startTimer();
                        nextQuestion(data);
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr)
                        console.log(status)
                        console.log(error)
                        showToast('warning','Sorry there was a problem, please try again ')
                        showError(xhr.responseText)
                        stopTimer()

                    }
                });
                document.getElementById('quizModal').style.display = 'block';
                document.getElementById('quizModal').classList.add('show');
            }

            function nextQuestion(question) {
                if(question.finished){
                    stopTimer();

                    location.reload();
                    console.log(question);
                    return;
                }
                let quizContent =document.getElementById('quizContent');
                quizContent.innerHTML = '';
                document.getElementById('progress-count').innerText = `${currentQuestionIndex} of ${questionsCount}`;
                let correct = 0;
                question.answers.forEach((answer, index) => {
                    correct = answer.is_correct ? answer.id : correct;

                    quizContent.innerHTML+=`<div class="form-check">
                                        <input class="form-check-input" type="radio" name="answer" id="answer${index}" value="${answer.id}">
                                        <label class="form-check-label" for="answer${index}"></label>
                                    </div>`;
                    $(quizContent).find('label[for="answer'+index+'"]').text(answer.text);
                });
                document.getElementById('quesText').innerText = question.question.text;
                // document.getElementById('quizContent').innerHTML = quizContent;
                document.getElementById('nextButton').onclick = () => evaluateAnswer(correct, question.question.id);
            }

            function evaluateAnswer(correctAnswer,questionId) {
                const selectedAnswer = document.querySelector('input[name="answer"]:checked')?.value;
                if (selectedAnswer == correctAnswer) {
                    correctAnswers++;
                }
                if (currentQuestionIndex === questionsCount) {
                    document.getElementById('nextButton').textContent = 'Submit';
                }
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route('quiz.next')); ?>',
                    data:{
                        assignmentId:<?php echo e($lesson->content->id); ?>,
                        questionId:questionId,
                        answerId:selectedAnswer,
                        _token:'<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'JSON',

                    success: function (data) {
                        console.log(data);
                        let percentComplete=parseInt(currentQuestionIndex/questionsCount*100+'');
                        $('#videoUploadProgressParent .progress-text').html(percentComplete + '%');
                        $('#progressbar').width(percentComplete + '%');
                        $('#progressbar').attr('aria-valuenow', percentComplete);
                        currentQuestionIndex++;
                        nextQuestion(data);
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr)
                        console.log(status)
                        console.log(error)
                        showToast('warning','Sorry there was a problem, please try again ')

                        showError(xhr.responseText)
                    }
                });
            }

            function showResults() {
                let quizContent = `<h4>Quiz Completed</h4>`;
                quizContent += `<p>Your score: ${correctAnswers} out of ${questions.length}</p>`;
                document.getElementById('quizContent').innerHTML = quizContent;
                document.getElementById('nextButton').style.display = 'none';
                // document.getElementById('quizModal').style.display = 'none';
                // document.getElementById('quizModal').classList.remove('show');
            }
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/courses/lessons/take_assignment.blade.php ENDPATH**/ ?>