<!-- Navbar & Hero Start -->
<nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
    <a href="<?php echo e(route('home')); ?>" class="navbar-brand p-0">
        <img src=<?php echo e(asset('img/madd-logo2.jpg')); ?> alt="Logo" style="    max-height: 50px;max-width: 93px;">
    </a>
    <button class="navbar-toggler bg-primary white-text" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse">
        <span class="fa fa-bars"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav me-auto py-0">
            <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('home')? 'active':''); ?>">Home</a>
            <a href="<?php echo e(route('about')); ?>" class="nav-item nav-link <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('about')? 'active':''); ?>">About</a>
            <a href="<?php echo e(route('course.index')); ?>" class="nav-item nav-link  <?php echo e(\Illuminate\Support\Facades\Route::currentRouteNamed('course.index')? 'active':''); ?>">Courses</a>

        </div>
        <div class="navbar-nav">
            <?php if(\Illuminate\Support\Facades\Auth::user()): ?>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link "
                       data-bs-toggle="dropdown"><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></a>
                    <div class="dropdown-menu m-0">
                        <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item">Dashboard</a>
                        <span class="divider-horizontal dropdown-divider"></span>
                        <a title="Logout" class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="text-danger   fa fa-solid fa-sign-out"> </i> <span data-no-translation>Logout</span></a>
                    </div>
                </div>

            <?php else: ?>
                <a title="sign-up" class="nav-item nav-link " href="<?php echo e(route('login')); ?>">
                <span data-no-translation>
                        Sign Up</span></a>
            <?php endif; ?>

        </div>


    </div>
    <aside class="submenu-popup-container">
    </aside>

</nav>

<!-- Navbar & Hero End -->
<?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/component/nav_bar.blade.php ENDPATH**/ ?>