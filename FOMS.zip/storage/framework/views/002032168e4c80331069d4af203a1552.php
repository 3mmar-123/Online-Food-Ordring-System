<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo e(asset('backend/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/custom.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('libs/fontawesome-6.4.0/css/all.css')); ?>">
  <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper" id="app">

    <?php echo $__env->make('layouts.backend.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.backend.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="content-wrapper">

    <?php echo $__env->yieldContent('content'); ?>
  </div>

  <?php echo $__env->make('layouts.backend.inc.control-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- ./wrapper -->


<script>
  setTimeout(function() {
      $('#alert').fadeOut('fast');
  }, 6000);
</script>
<script src="<?php echo e(asset('backend/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/custom.js')); ?>"></script>



<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/layouts/backend/master.blade.php ENDPATH**/ ?>