
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lesson Management</title>
    <!-- MDB 6.2 CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css">
    <style>
        .drag-area {
            border: 2px dashed #aaa;
            border-radius: 10px;
            position: relative;
            width: 100%;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            padding: 20px;
            font-size: 18px;
            color: #aaa;
        }
        .drag-area.dragging {
            border-color: #3f51b5;
            color: #3f51b5;
        }
    </style>

</head>
<body>

<div class="container py-5">

    <div class="row">
        <div class="col-12">
            <h2 class="mb-4">Lesson Details & Management</h2>
        </div>
    </div>
    <div class="modal fade" id="createLessonModal<?php echo e($module->id); ?>" tabindex="-1"
         aria-labelledby="createLessonModalLabel<?php echo e($module->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createLessonModalLabel<?php echo e($module->id); ?>">Update
                        Lesson</h5>
                    <button type="button" class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('lesson.store')); ?>"
                          id="createLessonForm<?php echo e($module->id); ?>"
                          method="POST"
                          novalidate>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="module_id"
                               value="<?php echo e($module->id); ?>"/>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-outline ">
                                    <input type="number" id="modalLessonOrder<?php echo e($module->id); ?>"
                                           name="lesson_order"
                                           value="<?php echo e($module->lessons_count+1); ?>"
                                           min="1"
                                           class="form-control  <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                    <label class="form-label"
                                           for="modalLessonOrder<?php echo e($module->id); ?>">Lesson
                                        Order</label>
                                    <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-outline mb-4">
                                    <input type="text" id="modalLessonTitle<?php echo e($module->id); ?>"
                                           name="lesson_title"
                                           value="<?php echo e(old('lesson_title')); ?>"
                                           class="form-control <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                    <label class="form-label"
                                           for="modalLessonTitle<?php echo e($module->id); ?>">Lesson
                                        Title</label>
                                    <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-outline mb-4">
                                                            <textarea class="form-control" id="modalLessonDescription<?php echo e($module->id); ?>"
                                                                      name="lesson_description"
                                                                      rows="4">

                                                            </textarea>
                            <label class="form-label"
                                   for="modalLessonDescription<?php echo e($module->id); ?>">Lesson
                                Description</label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal">Cancel
                    </button>
                    <button type="submit" form="createLessonForm<?php echo e($module->id); ?>"
                            class="btn btn-primary">Create Lesson
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Lesson Details Form -->
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title mb-4">Edit Lesson Details</h4>
            <form>
                <!-- Lesson Title -->
                <div class="form-outline mb-4">
                    <input type="text" id="lessonTitle" class="form-control" value="Understanding the Basics of Quantum Mechanics" required />
                    <label class="form-label" for="lessonTitle">Lesson Title</label>
                </div>

                <!-- Lesson Description -->
                <div class="form-outline mb-4">
                    <textarea class="form-control" id="lessonDescription" rows="4" required>This lesson will introduce you to the fundamental concepts of quantum mechanics...</textarea>
                    <label class="form-label" for="lessonDescription">Lesson Description</label>
                </div>
                <div class="drag-area" id="dragArea">
                    <div class="icon"><i class="fas fa-cloud-upload-alt"></i></div>
                    <header>Drag & Drop to Upload File</header>
                    <span>OR</span>
                    <button type="button" class="btn btn-light mt-2">Browse File</button>
                    <input type="file" hidden id="videoUpload" accept="video/*">
                </div>


                <!-- Optional Resources -->
                <div class="form-outline mb-4">
                    <input type="text" id="optionalResources" class="form-control" />
                    <label class="form-label" for="optionalResources">Optional Resources (URLs)</label>
                </div>
            </form>
        </div>
    </div>


</div>

<!-- MDB 6.2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"></script>
<script>
    const dragArea = document.getElementById('dragArea');
    const input = document.getElementById('videoUpload');
    let file; // this is a global variable and we'll use it inside multiple functions

    dragArea.addEventListener('click', () => input.click());

    input.addEventListener('change', function() {
        file = this.files[0];
        showFile(); // call the showFile function here
    });

    // If user Drag File Over DragArea
    dragArea.addEventListener('dragover', (event) => {
        event.preventDefault(); // preventing from default behaviour
        dragArea.classList.add('dragging');
    });

    // If user leave dragged File from DragArea
    dragArea.addEventListener('dragleave', () => {
        dragArea.classList.remove('dragging');
    });

    // If user drop File on DragArea
    dragArea.addEventListener('drop', (event) => {
        event.preventDefault(); // preventing from default behaviour
        file = event.dataTransfer.files[0];
        showFile(); // call the showFile function here
    });

    function showFile() {
        let fileType = file.type; // getting selected file type
        let validExtensions = ["video/mp4", "video/webm", "video/ogg"]; // adding some valid video extensions in array
        if(validExtensions.includes(fileType)){ // if the file is valid we show it
            let fileReader = new FileReader(); // creating new FileReader object
            fileReader.onload = () => {
                let fileURL = fileReader.result; // passing user file source in fileURL variable
                // UNCOMMENT THE NEXT LINE IF YOU WANT TO SHOW THE VIDEO PREVIEW
                // let imgTag = `<video src="${fileURL}" width="320" height="240" controls></video>`; // creating an video tag and passing user selected file source inside src attribute
                // dragArea.innerHTML = imgTag; // adding that created video tag inside dragArea container
            }
            fileReader.readAsDataURL(file);
            dragArea.classList.remove('dragging');
        }else{
            alert("This is not a valid Video file!");
            dragArea.classList.remove('dragging');
        }
    }
</script>

</body>
</html>

<?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/courses/show_lesson2.blade.php ENDPATH**/ ?>