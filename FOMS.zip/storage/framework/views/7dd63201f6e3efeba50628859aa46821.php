<?php $__env->startSection('styles'); ?>
    <style>

        @media (min-width: 1281px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("img/fields/resources.png")); ?>');
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("img/fields/resources.png")); ?>');
            }

        }

        @media (min-width: 1025px) and (max-width: 1280px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("img/fields/resources.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');
            }

        }

        /* Media Query for Tablets Ipads portrait mode */
        @media (min-width: 768px) and (max-width: 1024px) {
            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 52% 15%);
                background-image: url('<?php echo e(asset("img/fields/resources.png")); ?>');
            }

            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                background-image: url('<?php echo e(asset("wp-content/uploads/2023/04/second2.png")); ?>');

            }
        }

        /* Media Query for low resolution like mobiles */
        @media (min-width: 320px) and (max-width: 767px) {
            .one-stop-shop-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                -webkit-clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
                clip-path: polygon(0 0, 0 80%, 100% 100%, 100% 2%, 100% 0);
            }

            .quick-response-div-bg {
                background-position: 50% 50%;
                background: linear-gradient(to right, #333843, #323541);
                clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 56% 15%);
                -webkit-clip-path: polygon(0% 1%, 0% 100%, 100% 100%, 100% 0%, 53% 15%);
            }
        }
    </style>
    <style>
        .testimonial-item {
            perspective: 1000px;
            position: relative;
        }

        .owl-item .testimonial-item {
            background: white !important;
            border-color: var(--primary) !important;
            width: 100%;
            height: 100%;
        }

        .card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            min-height: 150px;
            transform-style: preserve-3d;
            transition: transform 0.6s ease;
        }

        .owl-item:hover .card-inner {
            transform: rotateY(180deg);
        }

        .card-front,
        .card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-front {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background-color: #fff;
        }

        .card-front img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: absolute;
            z-index: 1;
        }

        .card-front h3 {
            width: 100%;
            object-fit: cover;
            position: relative;
            z-index: 2;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.6);
            color: rgba(255, 255, 255, 0.73);

        }

        .card-back {
            background: rgba(0, 0, 0, 0.6);
            transform: rotateY(180deg);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            text-align: center;
        }

        .card-back h3 {
            margin: 0 0 10px;
            font-size: 1.3em;
            color: rgba(255, 255, 255, 0.73);
        }

        .card-back p {
            margin: 0;
            font-size: 0.8em;
            color: rgba(255, 255, 255, 0.73);

        }

        .start-container .col {
            background: #ccf1d199;
            border-style: groove;
            border-radius: 20%;
            padding-block: 10px;
            margin: 7px;
        }

    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('hero'); ?>
    <!--  Hero Start -->
    <div class="container-fluid bg-primary p-0 hero-header">
        <div class="img-hero">
            <img src="<?php echo e(asset('img/hero.png')); ?>"/>
        </div>
        <div class="hero-bg"></div>
    </div>
    <!--  Hero End -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Clients Trust Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center  wow fadeInUp" data-wow-delay="0.1s">
                <h1>Protect yourself and your data online.</h1>
            </div>
            <div class="owl-carousel owl-theme testimonial-carousel position-relative">
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/network2.png')); ?>" alt="Card Image">
                            <h3>Network Security </h3>
                        </div>
                        <div class="card-back">
                            <h3>Network Security </h3>
                            <p class="text-muted">Firewall Configuration, Network Segmentation, VPN and Secure
                                Tunneling</p>
                        </div>
                    </div>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/eH.png')); ?>" alt="Card Image">
                            <h3> Ethical Hacker</h3>
                        </div>
                        <div class="card-back">
                            <h3>Ethical Hacker </h3>
                            <p class="text-muted">Testing security weaknesses and recommending improvements.
                            </p>
                        </div>
                    </div>

                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/cloud.png')); ?>" alt="Card Image">
                            <h3>Cloud and IoT</h3>
                        </div>
                        <div class="card-back">
                            <h3>Cloud and IoT</h3>
                            <p class="text-muted">Cloud Security Models, IoT Device Security, Data Privacy and
                                Compliance
                            </p>
                        </div>
                    </div>

                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/crypto.png')); ?>" alt="Card Image">
                            <h3>Cryptography </h3>
                        </div>
                        <div class="card-back">
                            <h3>Cryptography </h3>
                            <p class="text-muted">Encryption, Digital Signatures, Cryptanalysis </p>
                        </div>
                    </div>

                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/Incident Response.png')); ?>" alt="Card Image">
                            <h3>Incident Response </h3>
                        </div>
                        <div class="card-back">
                            <h3> Incident Response</h3>
                            <p class="text-muted">Incident Detection, Containment, Recovery, Post-Incident Analysis</p>
                        </div>
                    </div>
                </div>
                <div class='testimonial-item bg-white text-center border'>
                    <div class="card-inner">
                        <div class="card-front">
                            <img src="<?php echo e(asset('img/fields/analyses.png')); ?>" alt="Card Image">
                            <h3>Security Analyst </h3>
                        </div>
                        <div class="card-back">
                            <h3>Security Analyst</h3>
                            <p class="text-muted">Threat Intelligence, Security Monitoring, Threat Detection</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Clients Trust End -->

            <!-- Choose us Start -->
            <div class="container-xxl py-5">
                <div class="container">
                    <div class="row g-5">

                        <div class=" wow fadeInUp" data-wow-delay="0.3s">
                            <h1 class="mb-4 text-center">
                                <span>Secure Your Digital Future</span></h1>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-xxl quick-response-div-bg row-flex vc_custom_1685098197489 ">
                <div class="container">
                    <div class="row white-text">

                        <div class="col-sm-12 col-lg-6 col-md-6">
                            <div class=" why-choose-content-1">
                                <h1 class="mt-3 quick-response-h text-center white-text wow fadeInRight"
                                    data-wow-delay="0.3s">
                                    <span>Data Protection</span></h1>
                                <p class="quick-response-p wow fadeInDown"
                                   data-wow-delay="0.4s">Learn how to safeguard your data, including
                                    sensitive personal information and critical business assets, from cyber threats.

                                </p>

                            </div>
                        </div>
                        <div class="col-sm-12 col-lg-6 col-md-6">
                            <div class=" why-choose-content-1">
                                <h1 class="mt-3 quick-response-h text-center white-text wow fadeInRight"
                                    data-wow-delay="0.3s">
                                    <span>Threat Mitigation</span></h1>
                                <p class="quick-response-p wow fadeInDown"
                                   data-wow-delay="0.4s">Understand the landscape of cyber threats and how to
                                    effectively defend against malware, phishing attacks, ransomware, and other common
                                    vulnerabilities. </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-xxl one-stop-shop-div-bg row-flex vc_custom_1685100562072 ">
                <div class="container">
                    <div class="row white-text">
                        <div class="col-sm-12 col-lg-6 col-md-6 ">
                            <div class=" why-choose-content-2">
                                <h1 class=" wow fadeInLeft one-stop-shop-h text-center white-text"
                                    data-wow-delay="0.3s">
                                    <span>Cybersecurity Awareness</span>
                                </h1>
                                <p class="one-stop-shop-p wow fadeInDown"
                                   data-wow-delay="0.4s">Develop a strong foundation in cybersecurity awareness,
                                    identifying and mitigating potential vulnerabilities in your online presence and
                                    operations.
                                </p>


                            </div>
                        </div>
                        <div class="d-sm-none col-lg-6 col-md-6"></div>

                    </div>
                </div>
            </div>
            <!-- Choose us End -->
            <!-- Quick Response and One Stop Shop Technology Start -->
            <div class="container-xxl row-flex mt-auto">
                <div class="container">
                    <div class="rounded-2 border-3 ">
                        <h2  class="mt-2 wow fadeInDown"
                            data-wow-delay="0.4s">Start Your Cybersecurity Journey with Us</h2>
                        <div class="row text-center start-container">
                            <div class="col wow fadeInLeftBig"
                                 data-wow-delay="0.1s">
                                <span><i class="fa fa-2xl fa-1"></i> </span>
                                <h3>Learn</h3>
                                <span>Acquire in-demand skills.</span>
                            </div>
                            <div class="col wow fadeInLeft"
                                 data-wow-delay="0.3s">
                                <span><i class="fa fa-2xl fa-2"></i> </span>
                                <h3>Advance</h3>
                                <span>Boost your career prospects.
</span>
                            </div>
                            <div class="col wow fadeInLeft"
                                 data-wow-delay="0.5s">
                                <i class="fa fa-2xl fa-3"></i>
                                <h3>Protect</h3>
                                <span class="text-muted">Secure your digital future.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/index.blade.php ENDPATH**/ ?>