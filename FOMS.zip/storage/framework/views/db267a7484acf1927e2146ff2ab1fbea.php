<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/quill.css')); ?>"
          rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-5 mt-5">
        <div class="card shadow mb-4">
            <div class="card-body">
                <h4 class="card-title">
                    <a href="<?php echo e(route('course.show',$lesson->module->course_id)); ?>"
                       class="text-primary"><i class="fas fa-arrow-circle-left"></i>
                    </a> <?php echo e($lesson->module->course->title.": Lesson"); ?>

                    : <?php echo e($lesson->title); ?>

                    <?php if($is_owner): ?>
                        <i data-bs-toggle="modal"
                           data-bs-target="#updateLessonModal"
                           class="float-end text-success fa-sharp fa-solid fa-edit"></i>
                    <?php endif; ?>
                </h4>
                <?php if($is_owner): ?>
                    <div class="modal fade" id="updateLessonModal" tabindex="-1"
                         aria-labelledby="updateLessonModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="updateLessonModalLabel">Update Lesson</h5>
                                    <button type="button" class="btn-close"
                                            data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('lesson.update')); ?>"
                                          id="updateLessonForm"
                                          method="POST"
                                          novalidate>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="lesson_id"
                                               value="<?php echo e($lesson->id); ?>"/>
                                        <div class="row mb-2">
                                            <div class="col-3">
                                                <div class="form-outline ">
                                                    <input type="number" id="modalLessonOrder"
                                                           name="lesson_order"
                                                           value="<?php echo e($lesson->order); ?>"
                                                           min="1"
                                                           class="form-control  <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="modalLessonOrder">Order</label>
                                                    <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-outline mb-4">
                                                    <input type="text" id="modalLessonTitle"
                                                           name="lesson_title"
                                                           value="<?php echo e($lesson->title); ?>"
                                                           class="form-control <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="modalLessonTitle">Title</label>
                                                    <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-outline mb-4">
                                            <textarea class="form-control" id="modalLessonDescription"
                                                      name="lesson_description"
                                                      rows="4">
                                                <?php echo e($lesson->description); ?>

                                            </textarea>
                                            <label class="form-label"
                                                   for="modalLessonDescription">Lesson Details</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancel
                                    </button>
                                    <button type="submit" form="updateLessonForm"
                                            class="btn btn-primary">Update Lesson
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <p class="ps-4 ms-5 text-muted"><?php echo e($lesson->description); ?>.</p>
            </div>
        </div>


        <!-- Video Presentation -->
        <div class="card shadow my-5">
            <div class="card-header">
                <h3 class="float-end card-header-tabs">

                    <?php if($is_owner&&$lesson->content): ?>
                        <?php if($lesson->type_id==2): ?>
                            <a class="edit-icon delete-question-btn text-muted me-2 fa-sharp fa-solid fa-edit"
                               href="<?php echo e(route('lesson.editContent',$lesson->id)); ?>"></a>
                        <?php else: ?>
                            <a class="edit-icon delete-question-btn text-danger me-2 fa-sharp fa-solid fa-trash"
                               href="#"
                               data-bs-toggle="modal"
                               onclick="showConfirmAlert('<?php echo e(route('lesson.destroyContent', $lesson->id)); ?>')"
                            ></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </h3>
            </div>
            <div class="card-body w-100 p-4 mx-auto">
                <div class="ratio ratio-16x9">
                    <?php if($lesson->content&&!session('allowEdit')): ?>
                        <?php if($lesson->type_id==1): ?>
                            <video id="lessonVideo" controls src="<?php echo e(asset($lesson->content->file_path)); ?>">
                            </video>
                        <?php elseif($lesson->type_id==2): ?>
                            <div class="styled-text">
                                <?php echo $lesson->content->file_path ?>
                            </div>
                        <?php endif; ?>
                    <?php elseif($is_owner): ?>
                        <form method="post" id="uploadLessonVideo" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="lesson_id" value="<?php echo e($lesson->id); ?>">
                            <?php if($lesson->type_id==1): ?>
                                <div class="drag-area mb-2" id="dragArea">
                                    <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="icon"><i class="fas fa-cloud-upload-alt"></i></div>
                                    <header>Drag & Drop to Upload File</header>
                                    <span>OR</span>
                                    <button type="button" class="btn btn-light mt-2">Browse File</button>
                                </div>
                                <div class="progress d-none mt-3 mb-3" id="videoUploadProgressParent">
                                    <div class="progress-bar progress-bar-animated" role="progressbar"
                                         id="videoUploadProgress" style="width: 0%;" aria-valuenow="0" aria-valuemin="0"
                                         aria-valuemax="100"></div>
                                    <div class="progress-text text-warning">0%</div>
                                </div>
                                <input type="file" hidden name="video" id="videoUpload" accept="video/*">

                            <?php elseif($lesson->type_id==2): ?>
                                <div id="editor" style="height:300px">
                                    <?php if(session('allowEdit')): ?>
                                        <?php echo $lesson->content->file_path ?>
                                    <?php endif; ?>
                                </div>

                                <!-- Hidden input to store the text content -->
                                <input type="hidden" name="text_content" id="text_content">
                            <?php endif; ?>
                            <button type="submit" id="btnUpload"
                                    class="btn btn-primary  mb-3" <?php echo e($lesson->type_id==1?'disabled':''); ?>>Upload
                            </button>
                        </form>

                    <?php else: ?>
                        <p class="text-muted text-center">Content Not Uploaded Yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>


        <!-- Lesson Navigation Buttons -->
        <div class="row my-4">
            <div class="col-12 d-flex justify-content-between align-items-center">
                <a class="btn btn-primary <?php echo e($prev_id??"disabled"); ?>"
                   href="<?php echo e(route('lesson.show',$prev_id??$lesson->id)); ?>"><i
                        class="fas fa-arrow-left"></i> Prev Lesson</a>
                <a class="btn btn-primary <?php echo e($next_id??"disabled"); ?>"
                   href="<?php echo e(route('lesson.show',$next_id??$lesson->id)); ?>">Next Lesson <i
                        class="fas fa-arrow-right"></i></a>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('js/quill.js')); ?>"></script>

    <!-- Initialize Quill editor and form submission handler -->
    <script>

    </script>
    <script>
        <?php if(!$is_owner): ?>
        document.addEventListener('DOMContentLoaded', function () {
            function sendPassRequest(id){
                const headers = new Headers({
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') // Ensure your HTML includes a meta tag for CSRF-token
                });

                const body = JSON.stringify({
                    lessonId: '<?php echo e($lesson->id); ?>', // Ensure this ID is correctly populated
                    status: 'passed'
                });
                fetch('<?php echo e(route('course.updateProgress')); ?>', { // Ensure the URL is correct
                    method: 'POST',
                    headers: headers,
                    body: body
                })
                    .then(response => response.text())
                    .then(data => {
                    })
                    .catch((error) => {
                        showToast('error', 'connection error');
                        showError(error.textResponse);
                        showError(error);
                        console.error('Error:', error)
                    })
            }
            <?php if(!$lesson->content): ?>
            console.error('pass')

            sendPassRequest();
            <?php elseif($lesson->type_id==1): ?>
            const video = document.getElementById('lessonVideo');
            let hasInteracted = false;
            video.ontimeupdate = function () {
                // const halfway = video.duration / 2;
                // Check if the video has reached halfway and there's no interaction
                if (!hasInteracted) {
                    sendPassRequest();
                    video.ontimeupdate = null;
                }
            };
            <?php else: ?>
            setInterval(function() {
                sendPassRequest();
            }, 3000);
            <?php endif; ?>
        });
        <?php endif; ?>
        <?php if($lesson->type_id==2): ?>
        var quill = new Quill('#editor', {
            theme: 'snow'
        });
        <?php endif; ?>

        $('form#uploadLessonVideo').submit(function () {
            $('#videoUploadProgressParent').removeClass('d-none');
            $('#btnUpload').addClass('disabled');
            <?php if($lesson->type_id==2): ?>
            var htmlContent = quill.root.innerHTML;
            // Set the content in hidden input
            document.getElementById('text_content').value = htmlContent;
            <?php endif; ?>
            var formData = new FormData($(this)[0]);
            $.ajax({
                xhr: function () {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total * 100;
                            $('#videoUploadProgressParent .progress-text').html(percentComplete + '%');
                            $('#videoUploadProgress').width(percentComplete + '%');
                            $('#videoUploadProgress').attr('aria-valuenow', percentComplete);
                        }
                    }, false);
                    return xhr;
                },
                url: '<?php echo e(session('allowEdit')? route('lesson.updateContent'): route('lesson.upload')); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.error) {
                        $('#videoUploadProgressParent .progress-text').removeClass('text-warning');
                        $('#videoUploadProgressParent .progress-text').removeClass('text-success');
                        $('#videoUploadProgressParent .progress-text').addClass('text-danger');
                    } else {
                        $('#videoUploadProgressParent .progress-text').removeClass('text-warning');
                        $('#videoUploadProgressParent .progress-text').removeClass('text-danger');
                        $('#videoUploadProgressParent .progress-text').addClass('text-success');
                        $('form#uploadLessonVideo').replaceWith(response.content);
                        showToast('success', 'Content Uploaded successfully');

                    }
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(
                        jqXHR, textStatus, error
                    )
                    showToast('error', 'Upload field check messages');
                    showError(jqXHR.responseText)
                    $('#videoUploadProgressParent .progress-text').removeClass('text-warning');
                    $('#videoUploadProgressParent .progress-text').removeClass('text-success');
                    $('#videoUploadProgressParent .progress-text').addClass('text-danger');
                }

            });

            return false;
        });
    </script>
    <script>
        const dragArea = document.getElementById('dragArea');
        if (dragArea) {
            let input = document.getElementById('videoUpload');
            let file; // this is a global variable and we'll use it inside multiple functions

            dragArea.addEventListener('click', () => input.click());

            input.addEventListener('change', function () {
                file = this.files[0];
                showFile(); // call the showFile function here
                return true;
            });

            // If user Drag File Over DragArea
            dragArea.addEventListener('dragover', (event) => {
                event.preventDefault(); // preventing from default behaviour
                dragArea.classList.add('dragging');
            });

            // If user leave dragged File from DragArea
            dragArea.addEventListener('dragleave', () => {
                dragArea.classList.remove('dragging');
            });

            // If user drop File on DragArea
            dragArea.addEventListener('drop', (event) => {
                event.preventDefault(); // preventing from default behaviour
                file = event.dataTransfer.files[0];
                showFile(); // call the showFile function here
            });

            function showFile() {
                let fileType = file.type; // getting selected file type
                let validExtensions = ["video/mp4", "video/webm", "video/ogg"]; // adding some valid video extensions in array
                if (validExtensions.includes(fileType)) { // if the file is valid we show it
                    let fileReader = new FileReader(); // creating new FileReader object
                    fileReader.onload = () => {
                        let fileURL = fileReader.result; // passing user file source in fileURL variable
                        // UNCOMMENT THE NEXT LINE IF YOU WANT TO SHOW THE VIDEO PREVIEW
                        let imgTag = `<video src="${fileURL}" width="320" height="240" controls></video>`; // creating an video tag and passing user selected file source inside src attribute

                        dragArea.innerHTML = imgTag; // adding that created video tag inside dragArea container
                    }
                    fileReader.readAsDataURL(file);
                    dragArea.classList.remove('dragging');
                    document.getElementById('btnUpload').removeAttribute('disabled');
                } else {
                    alert("This is not a valid Video file!");
                    dragArea.classList.remove('dragging');
                }

            }
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/courses/lessons/show_lesson.blade.php ENDPATH**/ ?>