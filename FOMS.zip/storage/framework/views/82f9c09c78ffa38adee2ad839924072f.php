<?php $__env->startSection('styles'); ?>
    <style>
        .question-container {
            margin-top: 20px;
        }

        .edit-icon {
            cursor: pointer;
        }

        .edit-icon:hover {
            cursor: pointer;
            box-shadow: 0 1px 15px 3px rgb(130 82 82 / 16%), 0 10px 20px 2px rgb(105 67 67 / 10%);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <!-- Assignment Details -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <h4 class="card-title"><a href="<?php echo e(route('course.show',$lesson->module->course_id)); ?>"
                                          class="text-primary"><i class="fas fa-arrow-circle-left"></i>
                    </a> <?php echo e($lesson->module->course->title.":".$lesson->type->text); ?>

                    : <?php echo e($lesson->title); ?>

                    <?php if($is_owner): ?>
                        <i data-bs-toggle="modal"
                           data-bs-target="#updateLessonModal"
                           class="float-end text-success fa-sharp fa-solid fa-edit"></i>
                    <?php endif; ?>
                </h4>
                <?php if($is_owner): ?>
                    <div class="modal fade" id="updateLessonModal" tabindex="-1"
                         aria-labelledby="updateLessonModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="updateLessonModalLabel">Update Assignment</h5>
                                    <button type="button" class="btn-close"
                                            data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('assignment.update')); ?>"
                                          id="updateLessonForm"
                                          method="POST"
                                          novalidate>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="assignment_id"
                                               value="<?php echo e($lesson->content->id); ?>"/>
                                        <div class="row mb-2">
                                            <div class="col-3">
                                                <div class="form-outline ">
                                                    <input type="number" id="modalLessonOrder"
                                                           name="lesson_order"
                                                           value="<?php echo e($lesson->order); ?>"
                                                           min="1"
                                                           class="form-control  <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="modalLessonOrder">Order</label>
                                                    <?php $__errorArgs = ['lesson_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-outline mb-4">
                                                    <input type="text" id="modalLessonTitle"
                                                           name="lesson_title"
                                                           value="<?php echo e($lesson->title); ?>"
                                                           class="form-control <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="modalLessonTitle">Title</label>
                                                    <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-2">
                                            <div class="col-4">
                                                <div class="form-outline mb-3">
                                                    <select class="form-select form-control "
                                                            name="assignment_type" id="assignment_type"
                                                    >
                                                        <?php $__currentLoopData = $assignmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                value="<?php echo e($key); ?>" <?php echo e($lesson->content->type_id==$key? 'selected':''); ?>><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <label for="assignment_type"
                                                           class="select-label form-label active">Assignment
                                                        Type</label>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-outline ">
                                                    <input type="number" id="quiz_time"
                                                           name="quiz_time"
                                                           value="<?php echo e($lesson->content->available_time); ?>"
                                                           class="form-control  <?php $__errorArgs = ['quiz_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="modalLessonOrder">Quiz Time (in minutes)</label>
                                                    <?php $__errorArgs = ['quiz_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-outline ">
                                                    <input type="number" id="total_marks"
                                                           name="total_marks"
                                                           value="<?php echo e($lesson->content->total_marks); ?>"
                                                           class="form-control  <?php $__errorArgs = ['total_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                    <label class="form-label"
                                                           for="total_marks">Total Marks</label>
                                                    <?php $__errorArgs = ['total_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-2">
                                            <div class="col">
                                                <div class="form-outline mb-3">
                                                    <input type="datetime-local"
                                                           class="form-control active"
                                                           value="<?php echo e($lesson->content->period_start); ?>"
                                                           name="open_date" id="open_date"
                                                    >
                                                    <label for="open_date" class=" form-label active">Open Date</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-outline mb-3">
                                                    <input type="datetime-local"
                                                           class="form-control active "
                                                           value="<?php echo e($lesson->content->period_end); ?>"
                                                           name="close_date" id="close_date">
                                                    <label for="close_date" class=" form-label active">Close
                                                        Date</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-outline mb-4">
                                            <textarea class="form-control" id="modalLessonDescription"
                                                      name="lesson_description"
                                                      rows="4">
                                                <?php echo e($lesson->description); ?>

                                            </textarea>
                                            <label class="form-label"
                                                   for="modalLessonDescription">Assignment Details</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancel
                                    </button>
                                    <button type="submit" form="updateLessonForm"
                                            class="btn btn-primary">Update Lesson
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <p><strong>Type:</strong> <?php echo e($lesson->content->type->text); ?></p>
                <p><strong>Description:</strong> <?php echo e($lesson->description); ?>.</p>
                <p><strong>Available Time:</strong> <?php echo e($lesson->content->available_time); ?> minutes</p>
                <p><strong>Total Marks:</strong> <?php echo e($lesson->content->total_marks); ?></p>
                <p><strong>Open Date:</strong> <?php echo e($lesson->content->period_start); ?></p>
                <p><strong>Close Date:</strong> <?php echo e($lesson->content->period_end); ?></p>
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Questions</h5>
                <?php if(Auth::user()->role_id==2&&Auth::user()->courses->contains($lesson->module->course_id)): ?>

                    <button class="btn btn-primary" id="btnAddQuestion" data-bs-toggle="modal"
                            data-bs-target=" #addQuestionModal"><i
                            class="fas fa-plus"></i> Add Question
                    </button>
                <?php endif; ?>
            </div>

            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $lesson->content->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item question-container" data-question="<?php echo e(json_encode($question)); ?>"
                        data-answers="<?php echo e(json_encode($question->answers)); ?>">
                        <?php echo e($question->text); ?><span
                            class="badge bg-primary float-end"><?php echo e($question->marks); ?> points</span>
                        <ul class="list-group">
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item <?php echo e($answer->is_correct&&$is_owner?'text-success':''); ?>"><?php echo e($answer->position.": ".$answer->text); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php if($is_owner): ?>
                            <div class=" d-flex w-100 p-2 justify-content-end  float-end">
                                <span class="edit-icon delete-question-btn text-danger me-2 fa-sharp fa-solid fa-trash"
                                      data-bs-toggle="modal"
                                      onclick="showConfirmAlert('<?php echo e(route('question.delete',$question->id)); ?>' )"
                                      data-question="<?php echo e($question->id); ?>"></span>
                                <span class="edit-icon edit-question-btn  me-3  float-end fas fa-edit"
                                      data-bs-toggle="modal"
                                      data-question="<?php echo e($question->id); ?>"
                                      data-bs-target="#addQuestionModal">

                                </span>
                            </div>

                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Add/Edit Question Modal -->
        <?php if($is_owner): ?>
            <div class="modal fade" id="addQuestionModal" tabindex="-1" aria-labelledby="addQuestionModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addQuestionModalLabel">Add/Edit Question</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="questionForm" method="POST" action="<?php echo e(route('question.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="question_id" id="question_id" value="">
                                <input type="hidden" name="quiz_id" value="<?php echo e($lesson->content->id); ?>">
                                <div class="form-outline mb-3">
                                    <input type="text" class="form-control" id="questionText" name="ques_text">
                                    <label for="questionText" class="form-label">Question</label>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="form-outline mb-3">
                                            <input type="number" class="form-control" name="ques_marks" id="ques_marks">
                                            <label for="ques_marks" class="form-label">Marks</label>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-outline mb-3">
                                            <select class="form-select form-control " name="ques_type"
                                                    id="questionType">
                                                <option value="MCQ">Multi-Choice</option>
                                                <option value="TF">True/False</option>
                                            </select>
                                            <label for="questionType" class="select-label form-label active">Question
                                                Type</label>
                                        </div>
                                    </div>
                                </div>
                                <div id="multiChoiceContainer">
                                    <div class="card">
                                        <div class="card-header d-flex justify-content-around" id="mcq-header">
                                            <h4>Choices</h4>
                                            <i id="btn-add-choice" class="btn  text-primary fas fa-add"></i>
                                            <div class="form-check">
                                                <input type="checkbox" checked class="form-check-input" name="can_shift"
                                                       id="canShiftAnswers">
                                                <label class="form-check-label" for="canShiftAnswers">Shift
                                                    Answers</label>
                                            </div>






                                        </div>
                                        <div class="card-body" id="choices-container">
                                            <div class="row choice-row mb-2" data-order="a">
                                                <div class="col-md-2">
                                                    <button type="button"
                                                            class="btn btn-warning btn-remove-choice disabled  btn-minus">
                                                        <i class="fas fa-minus"></i></button>
                                                </div>
                                                <div class="col-md-8 ">
                                                    <div class="form-outline flex-fill mb-2">
                                                        <input type="hidden" class="hidden-order"
                                                               name="choices[0][order]" value="a">
                                                        <span
                                                            class="yc-prefix prefix-scrollable yc-popover-output-prefix order-prefix"
                                                            data-order-prefix="a">
                                                    a.
                                                </span>
                                                        <input type="text"
                                                               class="form-control form-prefix-scrollable yc-popover-output active form-prefix choice-text"
                                                               id="choice_0_text" name="choices[0][text]">
                                                        <label class="form-label" for="choice_0_text">Choice
                                                            Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 align-content-end">
                                                    <div class="form-check form-outline">
                                                        <input class="form-check-input is-correct-chkbx" type="checkbox"
                                                               id="choice_0_isCorrect" name="choices[0][isCorrect]">
                                                        <label class="form-check-label choice-label"
                                                               for="choice_0_isCorrect">Correct</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row choice-row mb-2" data-order="b">
                                                <div class="col-md-2">
                                                    <button type="button"
                                                            class="btn btn-warning btn-remove-choice disabled  btn-minus">
                                                        <i class="fas fa-minus"></i></button>
                                                </div>
                                                <div class="col-md-8 ">
                                                    <div class="form-outline flex-fill mb-2">
                                                        <input type="hidden" class="hidden-order"
                                                               name="choices[1][order]" value="b">
                                                        <span
                                                            class="yc-prefix prefix-scrollable yc-popover-output-prefix order-prefix"
                                                            data-order-prefix="b">
                                                    b.
                                                </span>
                                                        <input type="text"
                                                               class="form-control form-prefix-scrollable yc-popover-output active form-prefix choice-text"
                                                               id="choice_1_text" name="choices[1][text]">
                                                        <label class="form-label" for="choice_1_text">Choice
                                                            Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 align-content-end">
                                                    <div class="form-check form-outline">
                                                        <input class="form-check-input is-correct-chkbx" type="checkbox"
                                                               id="choice_1_isCorrect" name="choices[1][isCorrect]">
                                                        <label class="form-check-label choice-label"
                                                               for="choice_1_isCorrect">Correct</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" form="questionForm">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php if($is_owner): ?>
        <script>
            const questionOrders = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'];

            $('#btn-add-choice').on('click', function (e) {
                // let newRow=$(this).parent().find('.row').last().clone();
                let newRow = $('#choices-container .choice-row:last-child').clone();

                let order_index = questionOrders.indexOf(newRow.data('order')) + 1;

                let order = questionOrders[order_index];

                newRow.attr('data-order', order)
                $('#choices-container').append(newRow);
                newRow.find('input.hidden-order').val(order);
                newRow.find('input.hidden-order').attr('name', 'choices[' + order_index + '][order]');
                let order_prefix = newRow.find('.order-prefix');
                order_prefix.data('order-prefix', order);
                order_prefix.html(order + '.')
                let input = newRow.find('input.choice-text');
                input.attr('id', 'choice_' + order_index + '_text');
                input.attr('name', 'choices[' + order_index + '][text]');
                input.next().attr('for', input.attr('id'));
                let chk = newRow.find('input.is-correct-chkbx');
                chk.attr('id', 'choice_' + order_index + '_isCorrect');
                chk.attr('name', 'choices[' + order_index + '][isCorrect]');
                chk.next().attr('for', input.attr('id'));
                $('.btn-remove-choice').removeClass('disabled');
                if ($('#choices-container .choice-row').length > 9)
                    $(this).addClass('disabled');
                setMCQListeners();

            });

            function rerangeChoices(startOrder) {
                console.log(startOrder)
                if ($('#choices-container .choice-row[data-order="' + startOrder + '"]').length)
                    return;
                console.log($('#choices-container .choice-row[data-order="' + startOrder + '"]'))
                let startIndex = questionOrders.indexOf(startOrder);
                console.log(startIndex)
                let length = $('#choices-container .choice-row').length;
                console.log(length)
                for (let i = startIndex + 1; i <= length; i++) {
                    let order = questionOrders[i - 1];
                    let newRow = $('#choices-container .choice-row[data-order="' + questionOrders[i] + '"]');
                    newRow.attr('data-order', order)
                    newRow.find('input.hidden-order').val(order);
                    newRow.find('input.hidden-order').attr('name', 'choices[' + i - 1 + '][order]');
                    let order_prefix = newRow.find('.order-prefix');
                    order_prefix.data('order-prefix', order);
                    order_prefix.html(order + '.')
                    let input = newRow.find('input.choice-text');
                    input.attr('id', 'choice_' + i - 1 + '_text');
                    input.attr('name', 'choices[' + i - 1 + '][text]');
                    input.next().attr('for', input.attr('id'));
                    let chk = newRow.find('input.is-correct-chkbx');
                    chk.attr('id', 'choice_' + i - 1 + '_isCorrect');
                    chk.attr('name', 'choices[' + i - 1 + '][isCorrect]');
                    chk.next().attr('for', input.attr('id'));
                }
            }

            function setMCQListeners() {

                $(' .btn-remove-choice').one('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log(e);
                    let row = $(this).closest('.choice-row').first();
                    let isLast = row.is('.choice-row:last-child');
                    row.remove();
                    if (!isLast) {
                        rerangeChoices(row.data('order'))
                    }
                    if ($('.btn-remove-choice').length == 2) {
                        $('.btn-remove-choice').addClass('disabled');
                    }
                });
                document.querySelectorAll('.is-correct-chkbx').forEach(function (choice) {
                    choice.onchange = function (event) {
                        if (this.checked ) {
                            document.querySelectorAll(".is-correct-chkbx:checked").forEach(function (chkdchoice) {
                                chkdchoice.removeAttribute('checked');
                                chkdchoice.checked = false;
                            })
                            this.checked = true;
                        }
                    }
                });
                formControlsSetUp();
            }

        </script>
        <script>

            document.getElementById('questionType').addEventListener('change', function () {
                const container = document.getElementById('choices-container');
                container.innerHTML = ''; // Clear previous inputs
                if (this.value === 'MCQ') {

                    container.innerHTML = `

                                            <div class="row choice-row mb-2" data-order="a">
                                                <div class="col-md-2">
                                                    <button type="button"
                                                            class="btn btn-warning btn-remove-choice disabled  btn-minus">
                                                        <i class="fas fa-minus"></i></button>
                                                </div>
                                                <div class="col-md-8 ">
                                                    <div class="form-outline flex-fill mb-2">
                                                        <input type="hidden" class="hidden-order"
                                                               name="choices[0][order]" value="a">
                                                        <span
                                                            class="yc-prefix prefix-scrollable yc-popover-output-prefix order-prefix"
                                                            data-order-prefix="a">
                                                    a.
                                                </span>
                                                        <input type="text"
                                                               class="form-control form-prefix-scrollable yc-popover-output active form-prefix choice-text"
                                                               id="choice_0_text" name="choices[0][text]">
                                                        <label class="form-label" for="choice_0_text">Choice
                                                            Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 align-content-end">
                                                    <div class="form-check form-outline">
                                                        <input class="form-check-input is-correct-chkbx" type="checkbox"
                                                               id="choice_0_isCorrect" name="choices[0][isCorrect]">
                                                        <label class="form-check-label choice-label"
                                                               for="choice_0_isCorrect">Correct</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row choice-row mb-2" data-order="b">
                                                <div class="col-md-2">
                                                    <button type="button"
                                                            class="btn btn-warning btn-remove-choice disabled  btn-minus">
                                                        <i class="fas fa-minus"></i></button>
                                                </div>
                                                <div class="col-md-8 ">
                                                    <div class="form-outline flex-fill mb-2">
                                                        <input type="hidden" class="hidden-order"
                                                               name="choices[1][order]" value="b">
                                                        <span
                                                            class="yc-prefix prefix-scrollable yc-popover-output-prefix order-prefix"
                                                            data-order-prefix="b">
                                                    b.
                                                </span>
                                                        <input type="text"
                                                               class="form-control form-prefix-scrollable yc-popover-output active form-prefix choice-text"
                                                               id="choice_1_text" name="choices[1][text]">
                                                        <label class="form-label" for="choice_1_text">Choice
                                                            Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 align-content-end">
                                                    <div class="form-check form-outline">
                                                        <input class="form-check-input is-correct-chkbx" type="checkbox"
                                                               id="choice_1_isCorrect" name="choices[1][isCorrect]">
                                                        <label class="form-check-label choice-label"
                                                               for="choice_1_isCorrect">Correct</label>
                                                    </div>
                                                </div>
                                            </div> `;
                    $('#haveMultiChoices,#canShiftAnswers,#btn-add-choice').removeClass('disabled');
                    document.getElementById('multiChoiceContainer')
                    document.getElementById('mcq-header').classList.add('d-flex');
                    document.getElementById('mcq-header').classList.remove('d-none');

                    setMCQListeners();
                } else if (this.value === 'TF') {
                    document.getElementById('mcq-header').classList.add('d-none');
                    document.getElementById('mcq-header').classList.remove('d-flex');


                    container.innerHTML = `
                                 <div class="align-content-end d-flex justify-content-center m-4">
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" checked value="T" name="answer"
                                                   id="answer_true">
                                            <label class="form-check-label" for="answer_true" >True</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" value="F" name="answer"
                                                   id="answer_false">
                                            <label class="form-check-label" for="answer_false">False</label>
                                        </div>
                                    </div>
                    `;
                    $('#haveMultiChoices,#canShiftAnswers,#btn-add-choice').addClass('disabled');
                }
            });
            document.getElementById('btnAddQuestion').addEventListener('click', function () {
                const container = document.getElementById('multiChoiceContainer');
                document.getElementById('question_id').value = '';
                document.getElementById('questionForm').reset();
                if(document.getElementById('mcq-header').classList.contains('d-none')){
                    document.getElementById('questionType').options[1].selected =true;
                }
                setMCQListeners();
            });
            document.querySelectorAll('.edit-question-btn').forEach(function (element) {
                element.addEventListener('click', function () {
                    const question = $(this.parentElement.parentElement).data('question');
                    const answers = $(this.parentElement.parentElement).data('answers');
                    console.log(answers)
                    const container = document.getElementById('choices-container');
                    container.innerHTML = '';
                    if (answers.length == 2 && (answers[0].text == "True" && answers[1].text == "False")) {
                        document.getElementById('questionType').options[1].selected=true;
                        container.innerHTML = `
                                 <div class="align-content-end d-flex justify-content-center m-4">
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" value="T" name="answer"
                                                    ${answers[0].is_correct ? 'checked' : ''}
                                                   id="answer_true">
                                            <label class="form-check-label" for="answer_true" >True</label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input type="radio" class="form-check-input" value="F" name="answer"
                                                    ${answers[1].is_correct ? 'checked' : ''}
                                                   id="answer_false">
                                            <label class="form-check-label" for="answer_false">False</label>
                                        </div>
                                    </div>
                    `;
                        document.getElementById('mcq-header').classList.add('d-none');
                        document.getElementById('mcq-header').classList.remove('d-flex');

                    } else {
                        document.getElementById('mcq-header').classList.add('d-flex');
                        document.getElementById('mcq-header').classList.remove('d-none');

                        document.getElementById('questionType').options[0].selected=true;
                        let corrects=0;
                        for (let index = 0; index < answers.length; index++) {
                            if(answers[index].is_correct){
                                corrects++;
                                console.error(index,answers[index])
                            }
                            $(container).append(`
                                           <div class="row choice-row mb-2" data-order="${answers[index].position}">
                                                <div class="col-md-2">
                                                    <button type="button"
                                                            class="btn btn-warning btn-remove-choice disabled  btn-minus">
                                                        <i class="fas fa-minus"></i></button>
                                                </div>
                                                <div class="col-md-8 ">
                                                    <div class="form-outline flex-fill mb-2">
                                                        <input type="hidden" class="hidden-order"
                                                               name="choices[${index}][order]" value="${answers[index].position}">
                                                        <span
                                                            class="yc-prefix prefix-scrollable yc-popover-output-prefix order-prefix"
                                                            data-order-prefix="${answers[index].position}">
                                                    ${answers[index].position}.
                                                </span>
                                                        <input type="text"
                                                               class="form-control form-prefix-scrollable yc-popover-output active form-prefix choice-text"
                                                               value=""
                                                               id="choice_${index}_text" name="choices[${index}][text]">
                                                        <label class="form-label" for="choice_${index}_text">Choice Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-2 align-content-end">
                                                    <div class="form-check form-outline">
                                                        <input class="form-check-input is-correct-chkbx" type="checkbox"
                                                               id="choice_${index}_isCorrect" ${answers[index].is_correct ? 'checked' : ''} name="choices[${index}][isCorrect]">
                                                        <label class="form-check-label choice-label"
                                                               for="choice_${index}_isCorrect">Correct</label>
                                                    </div>
                                                </div>
                                            </div>


                    `)
                            $(container).find(`#choice_${index}_text`).val(answers[index].text);
                        }
                        if(corrects>1){
                            document.getElementById('haveMultiChoices').checked=true;
                        }
                    }

                    if (answers.length > 2) {
                        $(container).find('.btn-remove-choice').removeClass('disabled');
                        if (answers.length > 9) {
                            $('#btn-add-choice').addClass('disabled');
                        } else {
                            $('#btn-add-choice').removeClass('disabled');

                        }
                    }
                    document.getElementById('question_id').value = question.id;
                    document.getElementById('questionText').value = question.text;
                    document.getElementById('ques_marks').value = question.marks;
                    document.getElementById('canShiftAnswers').checked = question.can_shift_answers;
                    document.getElementById('haveMultiChoices').checked = question.multi_choices;
                    formControlsSetUp();
                    setMCQListeners();

                });
            });
        </script>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\CSC\resources\views/courses/lessons/show_assignment.blade.php ENDPATH**/ ?>