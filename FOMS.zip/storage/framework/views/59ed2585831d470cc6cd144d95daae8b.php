<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 py-5">
        <!-- Teacher's Profile Section -->
        <div class="container mb-4">
            <div class="row g-5">
                <div class="card profile-card shadow-1-strong "
                     style=" border-radius: 20px;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0 d-flex align-items-center">
                                <div class="avatar me-3">
                            <span class="rounded-circle d-flex justify-content-center align-items-center"
                                  style="width: 50px; height: 50px; background-color: #455A64; color: white;"><?php echo e(substr(\Illuminate\Support\Facades\Auth::user()->name,0,1)); ?></span>
                                </div>
                                <div>
                                    <h5 class="card-title "><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h5>
                                </div>
                            </div>

                            <div class="col-lg-8 col-md-12 ">
                                <p class="pt-3 ">
                                    Welcome to your dashboard,
                                    Professor <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>! Here you can manage
                                    your courses, create new courses, and handle student enrollments.</p>
                                <div class="d-flex justify-content-end">
                                    <button type="button" class="btn btn-primary me-2" data-bs-toggle="modal"
                                            data-bs-target="#createCourseModal">
                                        Create New Course
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal modal-lg fade" id="createCourseModal" tabindex="-1"
                                         aria-labelledby="createCourseModalLabel" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="createCourseModalLabel">Create New
                                                        Course</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('course.store')); ?>" id="createCourseForm"
                                                          method="POST" enctype="multipart/form-data" novalidate>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-outline mb-4">
                                                            <input type="text" id="modalCourseTitle" name="title"
                                                                   value="<?php echo e(old('title')); ?>"
                                                                   class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                                            <label class="form-label" for="modalCourseTitle">Course
                                                                Title</label>
                                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="form-outline mb-4">
                                                            <textarea class="form-control" id="modalCourseDescription"
                                                                      name="description"
                                                                      rows="4"></textarea>
                                                            <label class="form-label" for="modalCourseDescription">Course
                                                                Description</label>
                                                        </div>

                                                        <div class="row mb-4">
                                                            <div class="col">
                                                                <!-- Select with search functionality -->
                                                                <div class="form-outline ">
                                                                    <select class="form-select form-control"
                                                                            name="category_id"
                                                                            id="courseCategorySelect">
                                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($id); ?>"><?php echo e($title); ?></option>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </select>
                                                                    <label class="form-label select-label"
                                                                           for="courseCategorySelect">Select Course
                                                                        Category</label>
                                                                </div>
                                                            </div>
                                                            <div class="col">
                                                                <!-- Select with search functionality -->
                                                                <div class="form-outline ">
                                                                    <select class="form-select form-control"
                                                                            name="level_id"
                                                                            id="courseLevelSelect">
                                                                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($id); ?>"><?php echo e($title); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </select>
                                                                    <label class="form-label select-label"
                                                                           for="courseCategorySelect">Select Course
                                                                        Level</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mb-4">
                                                            <label class="form-label" for="img_path">Course
                                                                Image</label>
                                                            <input type="file" class="form-control" name="img_path"
                                                                   id="img_path"/>

                                                        </div>

                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal" aria-label="Close">Close
                                                    </button>
                                                    <button type="submit" form="createCourseForm"
                                                            class="btn btn-primary">Save changes
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h3>Your Courses</h3>
            </div>
            <div class="card-body row">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4 course-container mb-4">
                        <div class="card hover-shadow ">
                            <img class="card-img-top" src="<?php echo e(asset($course->img_path??'img/logo1.webp')); ?>"
                                 alt="Course Image">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($course->title); ?></h5>
                                <p class="card-text"><?php echo e($course->description); ?></p>
                            </div>
                            <div class="card-footer">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="badge bg-success"><?php echo e($course->status->text); ?></span>
                                    <span><i class="fas fa-users"></i> <?php echo e($course->enrollments->count()); ?></span>

                                </div>

                                <p class="card-text mb3 course-rate" data-rate="<?php echo e($course->rating/500); ?>"></p>


                                <a href="<?php echo e(route('course.show',$course->id)); ?>" class="btn btn-primary">Go to course</a>
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted text-center ">
                        You haven't courses yet - <a href="#" data-bs-toggle="modal"
                                                     data-bs-target="#createCourseModal" class="me-3 link-success">Start With First Course </a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>
    <script>
        const selectElement = document.getElementById('courseCategorySelect');
        SearchBox.createSelectDropdown(selectElement);
        SearchBox.createSelectDropdown("select.form-select:not(.select-initialized)");

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/teacher_dashboard.blade.php ENDPATH**/ ?>