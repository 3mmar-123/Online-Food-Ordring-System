<?php $__env->startSection('styles'); ?>
    <style>
        body {
            background-color: #f4f5f7;
        }
        .course-header {
            background-color: #4b9e4d;
            color: white;
            padding: 20px;
            margin-top: 5rem;
        }
        .course-index, .lesson-details {
            height: calc(100vh - 72px); /* Adjust height accounting for header and padding/margins */
            overflow-y: auto;
        }
        .section-quiz-header {
            background-color: #e9ecef;
            padding: 20px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_bar'); ?>
    <?php echo $__env->make('component.nav_bar_sticky_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="course-header d-flex justify-content-between align-items-center">
    <h2>Python Essentials 1</h2>
    <div>
        <i class="fas fa-th-list fa-2x"></i>
        <i class="fas fa-book fa-2x mx-3"></i>
        <i class="fas fa-expand fa-2x"></i>
    </div>
</div>

<div class="d-flex">
    <!-- Course Index Section -->
    <div class="course-index overflow-scroll w-25 bg-white p-3">
        <h5>Course Outline</h5>
        <div class="mb-4">
            <strong>PE1: Module 2</strong>
            <div class="progress my-2">
                <div class="progress-bar" style="width: 57%;"></div>
            </div>
            <p>2.1. Section 1 - The "Hello, World!" Program (15/15)</p>
            <p>2.2. Section 2 - Python literals (8/8)</p>
            <p>2.3. Section 3 - Operators (5/5)</p>
            <p class="bg-success text-white">2.4. Section 4 - Variables (12/12)</p>
            <!-- ... More sections ... -->
        </div>
        <div class="mb-4">
            <strong>PE1: Module 2</strong>
            <div class="progress my-2">
                <div class="progress-bar" style="width: 57%;"></div>
            </div>
            <p>2.1. Section 1 - The "Hello, World!" Program (15/15)</p>
            <p>2.2. Section 2 - Python literals (8/8)</p>
            <p>2.3. Section 3 - Operators (5/5)</p>
            <p class="bg-success text-white">2.4. Section 4 - Variables (12/12)</p>
            <!-- ... More sections ... -->
        </div>
        <div class="mb-4">
            <strong>PE1: Module 2</strong>
            <div class="progress my-2">
                <div class="progress-bar" style="width: 57%;"></div>
            </div>
            <p>2.1. Section 1 - The "Hello, World!" Program (15/15)</p>
            <p>2.2. Section 2 - Python literals (8/8)</p>
            <p>2.3. Section 3 - Operators (5/5)</p>
            <p class="bg-success text-white">2.4. Section 4 - Variables (12/12)</p>
            <!-- ... More sections ... -->
        </div>
        <div class="mb-4">
            <strong>PE1: Module 2</strong>
            <div class="progress my-2">
                <div class="progress-bar" style="width: 57%;"></div>
            </div>
            <p>2.1. Section 1 - The "Hello, World!" Program (15/15)</p>
            <p>2.2. Section 2 - Python literals (8/8)</p>
            <p>2.3. Section 3 - Operators (5/5)</p>
            <p class="bg-success text-white">2.4. Section 4 - Variables (12/12)</p>
            <!-- ... More sections ... -->
        </div>
        <div class="mb-4">
            <strong>PE1: Module 2</strong>
            <div class="progress my-2">
                <div class="progress-bar" style="width: 57%;"></div>
            </div>
            <p>2.1. Section 1 - The "Hello, World!" Program (15/15)</p>
            <p>2.2. Section 2 - Python literals (8/8)</p>
            <p>2.3. Section 3 - Operators (5/5)</p>
            <p class="bg-success text-white">2.4. Section 4 - Variables (12/12)</p>
            <!-- ... More sections ... -->
        </div>
        <!-- ... More modules ... -->
    </div>

    <!-- Lesson Details Section -->
    <div class="lesson-details overflow-scroll w-75 p-3">
        <div class="section-quiz-header">
            <h5>PE1: Module 2. Python Data Types, Variables, Operators, and Basic I/O Operations</h5>
            <span>2.4.12 SECTION QUIZ</span>
        </div>
        <!-- Lesson Content Here -->
        <div class="mt-3">
            <p>This section includes the details for the lesson and can include various types of content such as text, images, videos, and interactive elements.</p>
            <!-- ... -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Laravel\LMS-Project\LMS\resources\views/student/course.blade.php ENDPATH**/ ?>