<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        // Restaurants Table
        Schema::create('restaurants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('owner_id')->constrained('users', 'id')->cascadeOnDelete();
            $table->string('name', 100);
            $table->text('address')->nullable();
            $table->string('cuisine', 50)->nullable();
            $table->string('phone', 15)->nullable();
            $table->string('logo_url')->nullable();
            $table->longText('description')->nullable();
            $table->timestamps();
        });

        // Menus Table
        Schema::create('menus', function (Blueprint $table) {
            $table->id();
            $table->foreignId('restaurant_id')->constrained('restaurants', 'id')->cascadeOnDelete();
            $table->string('name', 100);
            $table->text('description')->nullable();
            $table->decimal('price', 10, 2);
            $table->string('image_url')->nullable();
            $table->boolean('availability')->default(true);
            $table->timestamps();
        });

        // Orders Table
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('users', 'id')->cascadeOnDelete();
            $table->foreignId('restaurant_id')->constrained('restaurants', 'id')->cascadeOnDelete();
            $table->dateTime('order_date')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->enum('status', ['pending', 'preparing', 'delivering', 'completed','rejected', 'canceled']);
            $table->decimal('total_amount', 10, 2);
            $table->json('delivery_info')->nullable();

            $table->boolean('is_favorite')->default(false);
            $table->boolean('hide_from_customer')->default(false);
            $table->boolean('hide_from_owner')->default(false);
            $table->timestamps();
        });

        // Order_Items Table
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders', 'id')->cascadeOnDelete();
            $table->foreignId('menu_id')->constrained('menus', 'id')->cascadeOnDelete();
            $table->integer('quantity');
            $table->decimal('subtotal', 10, 2);
            $table->timestamps();
        });

        // Payments Table
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders', 'id')->cascadeOnDelete();
            $table->dateTime('payment_date')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->decimal('amount', 10, 2);
            $table->text('notes')->nullable();
            $table->enum('method', ['credit_card', 'paypal', 'cash','other']);
            $table->enum('status', ['success', 'failed', 'pending']);
            $table->timestamps();
        });

        // Delivery Table
        Schema::create('delivery', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders', 'id')->cascadeOnDelete();
            $table->unsignedBigInteger('agent_id')->nullable();
            $table->text('delivery_address');
            $table->enum('delivery_status', ['assigned', 'in_transit', 'delivered']);
            $table->timestamps();
        });

        // Notifications Table
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users', 'id')->cascadeOnDelete();
            $table->text('message');
            $table->text('goto_url')->nullable();
            $table->boolean('is_read')->default(false);
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->string('related')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('delivery');
        Schema::dropIfExists('payments');
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('menus');
        Schema::dropIfExists('restaurants');
    }
};
